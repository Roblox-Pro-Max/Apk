# Hosting your own free chat relay

**Mail does not need any server.** The app talks straight to your mail provider (Gmail, Outlook, Yahoo, your own domain...) over IMAP/SMTP.
A server is only needed for **chat**, and it is a tiny relay that stores *encrypted* messages until the recipient's app picks them up.
The relay never sees message text, and it holds no private keys: those are created on your computer and never leave it.

Everybody can run their own relay, and people on different relays can still talk to each other (your address is `username@your-relay-host`).

## What the relay needs
One small process, SQLite file, ~20 MB RAM, outbound nothing, inbound HTTPS. It is built into the same program:

    ./poct_core --relay --port 8080 --db relay.db        # env: PORT, POCT_INVITE (optional invite code)

Designed for free tiers:
- **Free hosts may wipe the disk or go to sleep.** Apps keep their own full history locally. If a relay loses its data, each app notices and re-registers its username with the same keys automatically. Messages that were queued at that moment are lost.
- **Sleeping hosts** can need up to a minute to wake up; the app waits for that (60 s timeout) and retries every 3 s.
- Set `POCT_INVITE=secret` to keep strangers from creating accounts on your relay; give the code only to friends.
- Built-in limits: 64 KB per message, 2000 queued messages per user, 120 messages/min per IP, 30 days retention.

## Where to run it (check current terms, free tiers change often)
| Option | Good for | Caveats |
|---|---|---|
| **Oracle Cloud "Always Free" VM** or **Google Cloud e2-micro** | Most reliable: a real VM with a persistent disk | Needs a card for identity verification; setup is manual (steps below) |
| **Render / similar "free web service" with Docker** | Easiest: connect the Git repo, it builds the `Dockerfile` | Sleeps after inactivity and the disk is temporary (self-healing covers accounts, queued messages can be lost) |
| **A Raspberry Pi / old PC at home** | Free forever, you own the data | Needs a tunnel for HTTPS (e.g. Cloudflare Tunnel) |
Fly.io and several others no longer offer a free plan; verify before choosing.

### VM steps (Oracle / Google)
1. Create a small Linux VM, open ports 80 and 443. Point a (sub)domain at its IP (a free DuckDNS name works).
2. `sudo apt install build-essential cmake git libcurl4-openssl-dev libsqlite3-dev libsodium-dev`, copy this project over, then `cmake -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build && sudo cp build/poct_core /usr/local/bin/`
3. `sudo useradd -r relay`, copy `deploy/poct-relay.service` to `/etc/systemd/system/`, then `sudo systemctl enable --now poct-relay`
4. Install Caddy, use `deploy/Caddyfile` (automatic HTTPS). Check `https://your-domain/relay/health` returns `{"ok":true}`.
5. In the app: Chat tab, enter `https://your-domain`, choose a username. Share your address with friends.

### Docker hosts
Point the host at this repository (it finds `Dockerfile`), expose port 8080 (or let it set `PORT`), add a persistent disk mounted at `/data` if the plan offers one. The host provides HTTPS.

## Do I need DNS records (SPF / DKIM / DMARC)?
- **Using Gmail/Outlook/Yahoo etc. addresses:** no. Their own servers sign and deliver your mail.
- **Chat:** no, chat does not use email at all.
- **Only if you send mail from your own domain** through your own SMTP server or a relay API (Resend, Brevo...): add the SPF, DKIM and DMARC TXT records that provider shows you, otherwise Gmail will likely put your mail in spam. Typical DMARC start value on `_dmarc.yourdomain.com`: `v=DMARC1; p=none;`
