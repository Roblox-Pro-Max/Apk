# Building the Android app (Mail)

Targets Android 12 (API 31) up to Android 16 (API 36), arm64 phones. App name: **Mail**, id `com.personalmail.app`.
The C++ engine runs *inside* the app and serves the UI to a WebView on 127.0.0.1; nothing else is installed or needed.

> Renaming a zip (or folder) to `.apk` does **not** produce an installable app. An APK is compiled and signed code.
> The steps below make GitHub compile it for you, for free, from your phone's browser.

## Build the APK from a phone (no computer)
1. Create a free GitHub account and a **new repository** (private is fine).
2. In the repository choose **Add file → Upload files**, pick `Mail-Android-Project.zip`, and **Commit changes**.
3. Choose **Add file → Create new file**. For the name type `.github/workflows/build-apk.yml` (typing the slashes creates the folders). Paste the contents of the `build-apk.yml` file that came with the zip. **Commit changes.**
4. Open the **Actions** tab → **Build APK** → **Run workflow**. The first build takes roughly 15-25 minutes (it compiles TLS, curl, SQLite and libsodium for Android).
5. When it is green, open the repository's **Releases** (right column or the Code tab) and download **Mail.apk** directly. (It is also stored under the run's *Artifacts*, zipped.)
6. Open the downloaded file on the phone and allow "Install unknown apps" for your browser/Files app when Android asks.

If the run turns red, open it, open the failed step, and send me the last ~40 lines of that step's log.

## Build on a computer instead
Install Android Studio (or JDK 17 + Android SDK 36 + NDK 28.0.12433566 + CMake 3.22.1), then in `android/`: `gradle assembleRelease`.
The APK appears in `android/app/build/outputs/apk/release/`.

## Notes
- Updates: the APK is signed with the key in `android/app/mail-release.jks`, so a newer build installs over the old one and keeps your data. That key is for personal use only; create your own before sharing the app publicly.
- Data (mail database, chat keys) lives in the app's private storage (`allowBackup=false`).
- TLS trust: the app ships `assets/cacert.pem` (Mozilla CA list via the `certifi` package). Refresh it occasionally.
- Attachments: the paperclip/Attach button opens the system file picker; received attachments are saved to your Downloads folder; links in mail open in your browser.
- Notifications: on first start Android asks for permission to show notifications (Android 13+). A small silent "Mail is running" notification stays in the status bar: Android requires it for any app that keeps syncing in the background. New mail and chat messages then notify you even when the app is closed (not while it is on screen). Tap a notification to open the app.
- Timing and battery: on the phone the engine checks mail every 60 s and the chat relay every 6 s (desktop: 30 s / 3 s). A new mail can therefore take up to about a minute to notify. Instant "push" (IMAP IDLE) is not implemented yet. To stop background activity, remove the app's notification permission or force-stop it in Android settings; vendor battery savers (Xiaomi, Huawei, Samsung...) may also need "Unrestricted" battery for Mail.
- Layout: the app content sits below the status bar/camera area (insets are applied to a container, because WebView ignores its own padding). The extra gap of the top bar is `--top-gap` in `ui/index.html`.
- Limits of this version: no instant push, and notifications show the sender and subject (chat: the first 200 characters of the message).
