package com.personalmail.app;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

/** Starts the C++ mail/chat engine once per process. Used by the activity and by the background service. */
final class Engine {
    static { System.loadLibrary("poct"); }
    static final int PORT = 7878;
    private static boolean started;

    private static native void start(String dir, int port);

    /** Copies the UI and CA bundle into the private files folder, starts the engine if needed and waits until it accepts connections. */
    static synchronized void ensureRunning(Context ctx) throws Exception {
        if (!started) {
            File dir = ctx.getFilesDir();
            copyAsset(ctx, "ui/index.html", new File(dir, "ui/index.html"));   // refreshed on every process start so app updates ship the new UI
            copyAsset(ctx, "cacert.pem", new File(dir, "cacert.pem"));
            start(dir.getAbsolutePath(), PORT);
            started = true;
        }
        for (int i = 0; i < 100; i++) {                                         // wait (max 10 s)
            try (Socket sk = new Socket()) { sk.connect(new InetSocketAddress("127.0.0.1", PORT), 200); return; }
            catch (Exception e) { Thread.sleep(100); }
        }
    }

    private static void copyAsset(Context ctx, String name, File out) throws Exception {
        File parent = out.getParentFile();
        if (parent != null) parent.mkdirs();
        try (InputStream in = ctx.getAssets().open(name); OutputStream o = new FileOutputStream(out)) {
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }
}
