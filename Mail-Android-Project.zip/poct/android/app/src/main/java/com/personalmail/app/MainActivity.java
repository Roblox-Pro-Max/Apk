package com.personalmail.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.window.OnBackInvokedDispatcher;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

/** Hosts the web UI in a WebView. The mail/chat engine (C++) runs inside this same process and serves the UI on 127.0.0.1. */
public class MainActivity extends Activity {
    static { System.loadLibrary("poct"); }
    private static native void startEngine(String dir, int port);

    private static final int PORT = 7878;
    private WebView web;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setDecorFitsSystemWindows(false);                  // same edge-to-edge behaviour on Android 12 to 16
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);
        web.setOnApplyWindowInsetsListener((v, insets) -> {            // keep content clear of status bar, gesture bar and keyboard
            Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            return WindowInsets.CONSUMED;
        });
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, () -> moveTaskToBack(true));
        }
        new Thread(this::boot).start();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() { moveTaskToBack(true); }              // Android 12/12L; newer versions use the callback above

    private void boot() {
        try {
            File dir = getFilesDir();
            copyAsset("ui/index.html", new File(dir, "ui/index.html"));   // refreshed on every launch so app updates ship new UI
            copyAsset("cacert.pem", new File(dir, "cacert.pem"));
            startEngine(dir.getAbsolutePath(), PORT);
            for (int i = 0; i < 100; i++) {                              // wait (max 10 s) until the engine accepts connections
                try (Socket sk = new Socket()) { sk.connect(new InetSocketAddress("127.0.0.1", PORT), 200); break; }
                catch (Exception e) { Thread.sleep(100); }
            }
            runOnUiThread(() -> web.loadUrl("http://127.0.0.1:" + PORT + "/"));
        } catch (Throwable e) {
            runOnUiThread(() -> web.loadData("Could not start the mail engine: " + e, "text/plain", "utf-8"));
        }
    }

    private void copyAsset(String name, File out) throws Exception {
        File parent = out.getParentFile();
        if (parent != null) parent.mkdirs();
        try (InputStream in = getAssets().open(name); OutputStream o = new FileOutputStream(out)) {
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }
}
