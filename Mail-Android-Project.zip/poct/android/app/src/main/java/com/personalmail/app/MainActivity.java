package com.personalmail.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.window.OnBackInvokedDispatcher;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;

/** Hosts the web UI in a WebView. The mail/chat engine (C++) runs inside this same process and serves the UI on 127.0.0.1. */
public class MainActivity extends Activity {
    static { System.loadLibrary("poct"); }
    private static native void startEngine(String dir, int port);

    private static final int PORT = 7878;
    private static final int REQ_FILES = 77;
    private WebView web;
    private ValueCallback<Uri[]> chooser;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setDecorFitsSystemWindows(false);                  // same edge-to-edge behaviour on Android 12 to 16
        getWindow().getDecorView().setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);
        web.setOnApplyWindowInsetsListener((v, insets) -> {            // keep content clear of status bar, gesture bar and keyboard
            Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
            v.setPadding(i.left, i.top, i.right, i.bottom);
            return WindowInsets.CONSUMED;
        });
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");     // only our own page (127.0.0.1) is ever loaded here; mail HTML runs in a script-less sandboxed iframe
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("127.0.0.1".equals(u.getHost())) return false;
                openExternal(u.toString());                            // any other address opens in the user's browser, never inside the app
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {                 // "Attach" button in the composer
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try { startActivityForResult(p.createIntent(), REQ_FILES); }
                catch (Exception e) { chooser = null; return false; }
                return true;
            }
        });
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, () -> moveTaskToBack(true));
        }
        new Thread(this::boot).start();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILES) {
            if (chooser != null) {
                chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                chooser = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() { moveTaskToBack(true); }              // Android 12/12L; newer versions use the callback above

    private void openExternal(String url) {
        try {
            Uri u = Uri.parse(url);
            String sc = u.getScheme();
            if (!("http".equals(sc) || "https".equals(sc) || "mailto".equals(sc))) return;
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception ignored) { }
    }

    private static String safeName(String name) {
        if (name == null || name.isEmpty()) return "attachment";
        StringBuilder b = new StringBuilder();
        for (char c : name.toCharArray()) b.append("\\/:*?\"<>|".indexOf(c) >= 0 ? '_' : c);
        return b.toString();
    }

    /** Methods the web UI can call. */
    private class Bridge {
        @JavascriptInterface
        public void open(String url) { runOnUiThread(() -> openExternal(url)); }

        /** Saves an attachment served by the local engine into the public Downloads folder. */
        @JavascriptInterface
        public void save(String path, String name, String mime) {
            if (path == null || !path.startsWith("/api/attachment/")) return;
            final String safe = safeName(name);
            final String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
            new Thread(() -> {
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL("http://127.0.0.1:" + PORT + path).openConnection();
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                    v.put(MediaStore.Downloads.MIME_TYPE, type);
                    v.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (u == null) throw new Exception("cannot create the file");
                    try (InputStream in = c.getInputStream(); OutputStream o = getContentResolver().openOutputStream(u)) {
                        byte[] buf = new byte[16384]; int n;
                        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                    }
                    v.clear();
                    v.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(u, v, null, null);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved to Downloads: " + safe, Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    final String msg = String.valueOf(e.getMessage());
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Could not save the file: " + msg, Toast.LENGTH_LONG).show());
                }
            }).start();
        }
    }

    private void boot() {
        try {
            File dir = getFilesDir();
            copyAsset("ui/index.html", new File(dir, "ui/index.html"));   // refreshed on every launch so app updates ship new UI
            copyAsset("cacert.pem", new File(dir, "cacert.pem"));
            startEngine(dir.getAbsolutePath(), PORT);
            for (int i = 0; i < 100; i++) {                              // wait (max 10 s) until the engine accepts connections
                try (Socket sk = new Socket()) { sk.connect(new InetSocketAddress("127.0.0.1", PORT), 200); break; }
                catch (Exception e) { Thread.sleep(100); }
            }
            runOnUiThread(() -> web.loadUrl("http://127.0.0.1:" + PORT + "/"));
        } catch (Throwable e) {
            runOnUiThread(() -> web.loadData("Could not start the mail engine: " + e, "text/plain", "utf-8"));
        }
    }

    private void copyAsset(String name, File out) throws Exception {
        File parent = out.getParentFile();
        if (parent != null) parent.mkdirs();
        try (InputStream in = getAssets().open(name); OutputStream o = new FileOutputStream(out)) {
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }
}
