plugins { id("com.android.application") }

android {
    namespace = "com.personalmail.app"
    compileSdk = 36                       // Android 16
    ndkVersion = "28.0.12433566"          // NDK r28: 16 KB page-size aligned libraries by default

    defaultConfig {
        applicationId = "com.personalmail.app"
        minSdk = 31                       // Android 12
        targetSdk = 36                    // Android 16
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }     // virtually every phone since 2017; add "x86_64" for the emulator
        externalNativeBuild { cmake { arguments += listOf("-DANDROID_STL=c++_static", "-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON") } }
    }
    externalNativeBuild { cmake { path = file("../../CMakeLists.txt"); version = "3.22.1" } }

    // A fixed signing key lets you install new versions over the old one without losing data.
    // This is a personal-use key kept in the repo; create your own before publishing the app anywhere.
    signingConfigs {
        create("mail") {
            storeFile = file("mail-release.jks"); storePassword = "mailapp"; keyAlias = "mail"; keyPassword = "mailapp"
        }
    }
    buildTypes { release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("mail") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
