# Mail — a personal mail client with end-to-end encrypted chat

C++ engine (IMAP/SMTP via libcurl, SQLite FTS5 search, libsodium encryption, REST + SSE on 127.0.0.1) with a Gmail-style dark web UI.
Two parts: **Mail** (any IMAP/SMTP provider, no server needed) and **Chat** (end-to-end encrypted, through a tiny relay anyone can host for free, see HOSTING.md).

## Build and run (Linux/macOS)
    sudo apt install cmake libcurl4-openssl-dev libsqlite3-dev libsodium-dev    # macOS: brew install cmake curl sqlite libsodium
    cmake -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build
    ./build/poct_core        # run from this folder (it serves ./ui and creates poct.db here)
Open http://127.0.0.1:7878 and click **Add account**.

## Adding an account
Enter email + password. IMAP/SMTP servers are picked from the domain (Gmail, Outlook, Yahoo, iCloud, Yandex, Mail.ru);
other domains default to imap.<domain> / smtp.<domain>, and everything can be overridden under "Advanced settings".
Gmail, Yahoo and iCloud require an **app password**.

## Chat and encryption
Open the **Chat** tab, enter a relay address and pick a username; your address is `username@relay-host`. People on different relays can talk to each other.
- Keys (X25519 for encryption, Ed25519 for signatures) are generated on your machine by libsodium; messages are sealed on the sender's machine and opened on the recipient's. The relay stores only ciphertext.
- Sender keys are pinned on first contact (trust on first use). A message whose key does not match the pin is blocked. Compare **safety numbers** (shown in the chat header and Chat settings) in person to rule out interception.
- Run a relay: `./build/poct_core --relay --port 8080` (see HOSTING.md for free hosting).

## Look and feel
Dark, card-based lists (rounded-square avatars, sender, time, subject and a two-line preview), a bottom bar with Mail and Chat (unread badges) and a floating Compose / New chat button on phones; sidebar layout on desktop. Chat uses the same cards. The top bar sits below the camera/status area on the Android app.

## Mail features
HTML mail is shown in a script-less sandboxed frame after stripping everything executable (scripts, forms, event handlers, `javascript:` links); remote images are blocked until you press "Show images" (privacy), and a strict CSP backs this up.
Attachments: received ones are stored and downloadable (never rendered inline except safe images), sending supports up to 20 MB with Unicode file names. Rich-text composer (bold, italic, underline, lists, links), Cc, Drafts folder (local).
Chat delivery queue: messages that cannot be delivered (server asleep or down) are retried automatically for 7 days.

## Android
See ANDROID.md. `cmake -DPOCT_BUNDLED_DEPS=ON` builds curl (mbedTLS), SQLite, libsodium from source on any platform; Android always uses that.

## Tests (no real account needed)
    python3 tools/mock_mail_server.py &                 # fake IMAP :1143 / SMTP :1025, password "good"
    POCT_DB=/tmp/t.db POCT_PORT=7899 ./build/poct_core &
    python3 tools/ui_test.py                            # needs: pip install playwright && playwright install chromium
    python3 tools/chat_test.py                          # 2 relays, 4 users, attacks, delivery queue, browser UI (POCT_BIN=./build/poct_core)
    python3 tools/notify_test.py                        # events behind Android notifications: never for first sync, capped, chat previews
    python3 tools/rich_test.py                          # HTML safety/XSS, attachments, rich composer, drafts, server test (68 checks)
The mail suite covers account add/reject, sync, MIME decoding, search, star, trash, purge, reply, send, multi-account filtering and the mobile drawer.

## Known limitations
- Mail passwords and chat private keys are stored unencrypted in poct.db (file mode 0600). Next step: OS keychain or a passphrase.
- Chat has no forward secrecy yet (long-term keys), no group chats, no attachments, no message deletion/edit. Messages sitting on a relay that restarts are lost (free hosts).
- Not implemented yet: OAuth2 (Gmail/Outlook sign-in without app passwords), Resend/Brevo API sending, instant push (IMAP IDLE; the Android app polls every 60 s and notifies via a foreground service), IMAP folder sync (only INBOX is read; Sent/Drafts/Trash are local), attachments inside drafts, Bcc.
- Only INBOX is synced (last 50 messages); no attachments; HTML mail is shown as plain text.
- No OAuth2 (personal Outlook.com accounts may reject password login).
- Only tested against the mock server, not against real Gmail/Outlook servers.
- Android: the APK itself could not be built in the authoring environment (no Android SDK); the Gradle project, JNI entry point and cloud build workflow are included and the engine was tested with the same bundled dependency stack on desktop. The Dockerfile was also not test-built.
