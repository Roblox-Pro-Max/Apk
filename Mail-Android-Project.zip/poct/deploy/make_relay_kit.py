#!/usr/bin/env python3
"""Builds the two-file relay server kit (Dockerfile + render.yaml) with the engine source embedded, so it can be uploaded to a new
GitHub repository from a phone (no folders needed) and deployed on Render. Usage: python3 deploy/make_relay_kit.py OUTDIR"""
import base64, gzip, os, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); out = sys.argv[1] if len(sys.argv) > 1 else "relay-kit"; os.makedirs(out, exist_ok=True)
b64 = base64.b64encode(gzip.compress(open(f"{root}/core/main.cpp", "rb").read(), 9)).decode(); chunks = [b64[i:i + 20000] for i in range(0, len(b64), 20000)]
lines = ["# Mail chat relay: a tiny server that only ever stores end-to-end encrypted messages.",
 "# Self-contained: the source code is embedded below (gzip + base64), so this Dockerfile is the only file the build needs.",
 "FROM debian:12-slim AS build",
 "RUN apt-get update && apt-get install -y --no-install-recommends g++ curl ca-certificates libcurl4-openssl-dev libsqlite3-dev libsodium-dev && rm -rf /var/lib/apt/lists/*",
 "WORKDIR /src"]
for i, c in enumerate(chunks): lines.append(f"RUN printf '%s' '{c}' {'>' if i == 0 else '>>'} main.cpp.gz.b64")
lines += ["RUN base64 -d main.cpp.gz.b64 | gunzip > main.cpp",
 "RUN mkdir nlohmann && curl -fsSL -o httplib.h https://raw.githubusercontent.com/yhirose/cpp-httplib/v0.25.0/httplib.h && curl -fsSL -o nlohmann/json.hpp https://github.com/nlohmann/json/releases/download/v3.11.3/json.hpp",
 "RUN g++ -O1 -std=c++20 -I. main.cpp -o poct_core -lcurl -lsqlite3 -lsodium -pthread",
 "",
 "FROM debian:12-slim",
 "RUN apt-get update && apt-get install -y --no-install-recommends libcurl4 libsqlite3-0 libsodium23 ca-certificates && rm -rf /var/lib/apt/lists/* && useradd -m relay",
 "COPY --from=build /src/poct_core /usr/local/bin/poct_core",
 "USER relay",
 "WORKDIR /home/relay",
 "ENV PORT=10000",
 "# Set POCT_INVITE in the host's environment to make the server invite-only (render.yaml generates one for you).",
 'CMD ["sh","-c","exec poct_core --relay --db /home/relay/relay.db --port ${PORT}"]', ""]
open(f"{out}/Dockerfile", "w").write("\n".join(lines))
open(f"{out}/render.yaml", "w").write("""services:
  - type: web
    name: mail-relay
    runtime: docker
    plan: free
    healthCheckPath: /relay/health
    envVars:
      - key: POCT_INVITE
        generateValue: true
""")
open(f"{out}/README.md", "w").write("""# Mail chat relay (free hosting kit)

Two files: `Dockerfile` (contains the whole server) and `render.yaml`.

1. Create a free GitHub account and a **new repository** (public or private).
2. Upload `Dockerfile` and `render.yaml` to it (Add file, Upload files).
3. Create a free account on render.com, choose **New, Blueprint**, connect GitHub, pick the repository, **Apply**. The first build takes several minutes.
4. When the service is live, copy its address (https://something.onrender.com). In the service's **Environment** tab copy the generated **POCT_INVITE** value.
5. In the Mail app: Chat tab, paste the address, press **Test server**, enter the invite code, choose a username.

Good to know: Render's free plan puts the service to sleep after about 15 minutes without traffic and does not keep files between restarts.
The app copes with that: it keeps your messages locally, re-registers your username automatically and re-sends queued messages.
Messages that are waiting on the server while it restarts can be lost, and the first message after a sleep takes up to a minute.
For an always-on server use an always-free VM instead (see HOSTING.md in the main project).
""")
print("kit written to", out, "| dockerfile bytes:", os.path.getsize(f"{out}/Dockerfile"))
