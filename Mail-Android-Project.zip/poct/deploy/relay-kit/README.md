# Mail chat relay (free hosting kit)

Two files: `Dockerfile` (contains the whole server) and `render.yaml`.

1. Create a free GitHub account and a **new repository** (public or private).
2. Upload `Dockerfile` and `render.yaml` to it (Add file, Upload files).
3. Create a free account on render.com, choose **New, Blueprint**, connect GitHub, pick the repository, **Apply**. The first build takes several minutes.
4. When the service is live, copy its address (https://something.onrender.com). In the service's **Environment** tab copy the generated **POCT_INVITE** value.
5. In the Mail app: Chat tab, paste the address, press **Test server**, enter the invite code, choose a username.

Good to know: Render's free plan puts the service to sleep after about 15 minutes without traffic and does not keep files between restarts.
The app copes with that: it keeps your messages locally, re-registers your username automatically and re-sends queued messages.
Messages that are waiting on the server while it restarts can be lost, and the first message after a sleep takes up to a minute.
For an always-on server use an always-free VM instead (see HOSTING.md in the main project).
