// Android entry point: the Java activity calls startEngine() once; the C++ engine then serves the UI on 127.0.0.1:<port> inside the app process.
#include <jni.h>
#include <unistd.h>
#include <atomic>
#include <string>
#include <thread>
extern int poct_main(int, char**);
extern "C" JNIEXPORT void JNICALL Java_com_personalmail_app_MainActivity_startEngine(JNIEnv* env, jclass, jstring jdir, jint port) {
  static std::atomic<bool> started{false};
  if (started.exchange(true)) return;                       // activity recreated: engine already running
  const char* d = env->GetStringUTFChars(jdir, nullptr); std::string dir = d; env->ReleaseStringUTFChars(jdir, d);
  std::thread([dir, port] {
    if (chdir(dir.c_str()) != 0) return;                    // db, ui/ and cacert.pem live in the app's private files dir
    setenv("POCT_PORT", std::to_string(port).c_str(), 1);
    setenv("POCT_CA", (dir + "/cacert.pem").c_str(), 1);
    setenv("TMPDIR", dir.c_str(), 1);
    char a0[] = "poct_core"; char* argv[] = {a0, nullptr};
    poct_main(1, argv);
  }).detach();
}
