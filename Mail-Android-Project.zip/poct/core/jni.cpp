// Android entry point: Engine.start() is called once (by the activity or the background service); the C++ engine then serves the UI on 127.0.0.1:<port> inside the app process.
#include <jni.h>
#include <unistd.h>
#include <atomic>
#include <string>
#include <thread>
extern int poct_main(int, char**);
extern "C" JNIEXPORT void JNICALL Java_com_personalmail_app_Engine_start(JNIEnv* env, jclass, jstring jdir, jint port) {
  static std::atomic<bool> started{false};
  if (started.exchange(true)) return;                       // activity recreated: engine already running
  const char* d = env->GetStringUTFChars(jdir, nullptr); std::string dir = d; env->ReleaseStringUTFChars(jdir, d);
  std::thread([dir, port] {
    if (chdir(dir.c_str()) != 0) return;                    // db, ui/ and cacert.pem live in the app's private files dir
    setenv("POCT_PORT", std::to_string(port).c_str(), 1);
    setenv("POCT_CA", (dir + "/cacert.pem").c_str(), 1);
    setenv("TMPDIR", dir.c_str(), 1);
    setenv("POCT_SYNC_SECS", "60", 0);   // gentler polling than the desktop defaults (battery); the environment can still override
    setenv("POCT_CHAT_SECS", "6", 0);
    char a0[] = "poct_core"; char* argv[] = {a0, nullptr};
    poct_main(1, argv);
  }).detach();
}
