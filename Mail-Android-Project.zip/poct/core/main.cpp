// poct_core: IMAP/SMTP (libcurl) + SQLite FTS5 + REST/SSE. UI: ./ui
#include <httplib.h>
#include <nlohmann/json.hpp>
#include <sqlite3.h>
#include <sodium.h>
#include <sys/stat.h>
#include <unistd.h>
#include <curl/curl.h>
#include <algorithm>
#include <condition_variable>
#include <deque>
#include <filesystem>
#include <map>
#include <mutex>
#include <regex>
#include <set>
#include <sstream>
#include <thread>
#ifdef POCT_ANDROID
#define MAIN_FN poct_main      // called from jni.cpp inside the app process
#else
#define MAIN_FN main
#endif
using json = nlohmann::json;
using Args = std::vector<std::string>;
using namespace std::chrono_literals;
constexpr auto NP = std::string::npos;

// ---------- DB ----------
static sqlite3* db; static std::mutex dbm;
static std::string J(const json& j){ return j.dump(-1,' ',false,json::error_handler_t::replace); }
static json q(const std::string& sql,const Args& a={},long long* rowid=nullptr){
  std::lock_guard<std::mutex> l(dbm); sqlite3_stmt* s; json out=json::array();
  if(sqlite3_prepare_v2(db,sql.c_str(),-1,&s,0)!=SQLITE_OK){ fprintf(stderr,"SQL: %s\n",sqlite3_errmsg(db)); return out; }
  for(size_t i=0;i<a.size();++i) sqlite3_bind_text(s,(int)i+1,a[i].c_str(),-1,SQLITE_TRANSIENT);
  int n=sqlite3_column_count(s);
  int src; while((src=sqlite3_step(s))==SQLITE_ROW){ json o;
    for(int c=0;c<n;++c){ const char* nm=sqlite3_column_name(s,c);
      switch(sqlite3_column_type(s,c)){ case SQLITE_INTEGER:o[nm]=sqlite3_column_int64(s,c);break; case SQLITE_NULL:o[nm]=nullptr;break;
        default:o[nm]=std::string((const char*)sqlite3_column_text(s,c)); } }
    out.push_back(o); }
  if(src!=SQLITE_DONE)fprintf(stderr,"SQL step: %s\n",sqlite3_errmsg(db));
  if(rowid)*rowid=sqlite3_last_insert_rowid(db);
  sqlite3_finalize(s); return out;
}
static void init_db(const char* path){
  sqlite3_open(path,&db); sqlite3_busy_timeout(db,5000); char* e=nullptr;   // wait up to 5 s if another connection holds the write lock
  sqlite3_exec(db,
   "PRAGMA journal_mode=WAL;PRAGMA temp_store=MEMORY;"
   "CREATE TABLE IF NOT EXISTS accounts(id INTEGER PRIMARY KEY,email TEXT UNIQUE,pass TEXT,ih TEXT,ip INTEGER,sh TEXT,sp INTEGER,tls INTEGER,last_uid INTEGER DEFAULT 0);"
   "CREATE TABLE IF NOT EXISTS mails(id INTEGER PRIMARY KEY,account_id INTEGER,folder TEXT,uid INTEGER,sender TEXT,subject TEXT,body TEXT,ts INTEGER,"
   "unread INTEGER DEFAULT 1,starred INTEGER DEFAULT 0,UNIQUE(account_id,folder,uid));"
   "CREATE VIRTUAL TABLE IF NOT EXISTS mails_fts USING fts5(subject,body,sender,content='mails',content_rowid='id',tokenize='unicode61 remove_diacritics 2');"
   "CREATE TABLE IF NOT EXISTS identity(k TEXT PRIMARY KEY,v TEXT);"
   "CREATE TABLE IF NOT EXISTS contacts(addr TEXT PRIMARY KEY,box_pk TEXT,sign_pk TEXT,first_seen INTEGER);"
   "CREATE TABLE IF NOT EXISTS chats(id INTEGER PRIMARY KEY,peer TEXT,dir INTEGER,body TEXT,ts INTEGER,unread INTEGER DEFAULT 0,msgid TEXT UNIQUE);"
   "CREATE INDEX IF NOT EXISTS chats_peer ON chats(peer,id);"
   "CREATE TABLE IF NOT EXISTS r_users(handle TEXT PRIMARY KEY,box_pk TEXT,sign_pk TEXT,created INTEGER);"
   "CREATE TABLE IF NOT EXISTS r_box(id INTEGER PRIMARY KEY,handle TEXT,blob TEXT,ts INTEGER);"
   "CREATE INDEX IF NOT EXISTS r_box_h ON r_box(handle,id);"
   "CREATE TRIGGER IF NOT EXISTS m_ai AFTER INSERT ON mails BEGIN INSERT INTO mails_fts(rowid,subject,body,sender) VALUES(new.id,new.subject,new.body,new.sender); END;"
   "CREATE TRIGGER IF NOT EXISTS m_ad AFTER DELETE ON mails BEGIN INSERT INTO mails_fts(mails_fts,rowid,subject,body,sender) VALUES('delete',old.id,old.subject,old.body,old.sender); END;",
   0,0,&e);
  if(e){ fprintf(stderr,"init: %s\n",e); sqlite3_free(e); }
  for(const char* col:{"html TEXT","to_addr TEXT","cc TEXT"})sqlite3_exec(db,(std::string("ALTER TABLE mails ADD COLUMN ")+col+";").c_str(),0,0,nullptr);   // errors ignored: column already exists
  sqlite3_exec(db,"ALTER TABLE chats ADD COLUMN state INTEGER DEFAULT 0;",0,0,nullptr);   // 0 delivered, 1 queued for retry, 2 failed
  sqlite3_exec(db,"CREATE TABLE IF NOT EXISTS outbox(msgid TEXT PRIMARY KEY,peer TEXT,blob TEXT,ts INTEGER);",0,0,nullptr);
  sqlite3_exec(db,
   "CREATE TABLE IF NOT EXISTS attachments(id INTEGER PRIMARY KEY,mail_id INTEGER,name TEXT,mime TEXT,cid TEXT,size INTEGER,data BLOB);"
   "CREATE INDEX IF NOT EXISTS att_mail ON attachments(mail_id);"
   "CREATE TRIGGER IF NOT EXISTS m_ad2 AFTER DELETE ON mails BEGIN DELETE FROM attachments WHERE mail_id=old.id; END;"
   "CREATE TRIGGER IF NOT EXISTS m_au AFTER UPDATE OF subject,body,sender ON mails BEGIN "
   "INSERT INTO mails_fts(mails_fts,rowid,subject,body,sender) VALUES('delete',old.id,old.subject,old.body,old.sender); "
   "INSERT INTO mails_fts(rowid,subject,body,sender) VALUES(new.id,new.subject,new.body,new.sender); END;",0,0,nullptr);
}

// ---------- SSE ----------
static std::mutex evm; static std::condition_variable evcv; static std::deque<std::pair<long,std::string>> evs; static long evseq=0;
static void push_event(const json& j){ std::lock_guard<std::mutex> l(evm); evs.push_back({++evseq,J(j)}); if(evs.size()>100)evs.pop_front(); evcv.notify_all(); }

// ---------- MIME ----------
static int env_secs(const char* k,int d){ const char* v=getenv(k); int x=v?atoi(v):d; return x>=1?x:d; }
static std::string utf8_trunc(const std::string& s,size_t n){ if(s.size()<=n)return s; while(n>0&&((unsigned char)s[n]&0xC0)==0x80)--n; return s.substr(0,n); }
static std::string lower(std::string s){ for(auto&c:s)c=(char)tolower((unsigned char)c); return s; }
static std::string trim(const std::string& s){ size_t a=s.find_first_not_of(" \t\r\n"),b=s.find_last_not_of(" \t\r\n"); return a==NP?"":s.substr(a,b-a+1); }
static const char* B64="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static std::string b64dec(const std::string& in){ static int T[256]; static bool init=false;
  if(!init){ std::fill(T,T+256,-1); for(int i=0;i<64;i++)T[(unsigned char)B64[i]]=i; init=true; }
  std::string o; int v=0,b=-8; for(unsigned char ch:in){ if(T[ch]<0)continue; v=((v<<6)|T[ch])&0xFFFFFF; b+=6; if(b>=0){ o.push_back((char)((v>>b)&0xFF)); b-=8; } } return o; }
static std::string b64enc(const std::string& s,bool wrap=false){ std::string o; unsigned v=0; int b=-6; size_t col=0;
  for(unsigned char c:s){ v=((v<<8)|c)&0xFFFFFF; b+=8; while(b>=0){ o+=B64[(v>>b)&63]; b-=6; if(wrap&&++col%76==0)o+="\r\n"; } }
  if(b>-6)o+=B64[((v<<8)>>(b+8))&63]; while(o.size()%4&&!wrap)o+='='; if(wrap){ while((o.size()-(o.size()/78)*2)%4)o+='='; } return o; }
static std::string qpdec(const std::string& s,bool hdr=false){ std::string o;
  for(size_t i=0;i<s.size();++i){ char c=s[i];
    if(c=='='&&i+1<s.size()){
      if(s[i+1]=='\r'||s[i+1]=='\n'){ i++; if(s[i]=='\r'&&i+1<s.size()&&s[i+1]=='\n')i++; continue; }
      if(i+2<s.size()&&isxdigit((unsigned char)s[i+1])&&isxdigit((unsigned char)s[i+2])){ o+=(char)std::stoi(s.substr(i+1,2),nullptr,16); i+=2; continue; } }
    o+=(hdr&&c=='_')?' ':c; } return o; }
static std::string to_utf8(const std::string& s,std::string cs){ cs=lower(cs);
  if(cs.find("8859-1")!=NP||cs.find("1252")!=NP||cs=="latin1"){ std::string o; for(unsigned char c:s){ if(c<0x80)o+=(char)c; else{ o+=(char)(0xC0|(c>>6)); o+=(char)(0x80|(c&0x3F)); } } return o; }
  return s; }
static std::string decode_words(const std::string& s){ static const std::regex re(R"(=\?([^?]+)\?([bBqQ])\?([^?]*)\?=)");
  std::string out; auto it=s.cbegin(); std::smatch m; bool prev=false;
  while(std::regex_search(it,s.cend(),m,re)){ std::string between=m.prefix().str();
    if(!(prev&&between.find_first_not_of(" \t")==NP)) out+=between;
    std::string t=(m[2]=="b"||m[2]=="B")?b64dec(m[3].str()):qpdec(m[3].str(),true); out+=to_utf8(t,m[1].str()); prev=true; it=m.suffix().first; }
  out.append(it,s.cend()); return out; }
static void split(const std::string& r,std::string& h,std::string& b){ size_t p=r.find("\r\n\r\n"),k=4,p2=r.find("\n\n");
  if(p==NP||(p2!=NP&&p2<p)){ p=p2;k=2; } if(p==NP){ h=r;b="";return; } h=r.substr(0,p); b=r.substr(p+k); }
static std::map<std::string,std::string> hdrs(const std::string& h){ std::map<std::string,std::string> m; std::string name,val,line; std::istringstream is(h);
  auto flush=[&]{ if(!name.empty()&&!m.count(name))m[name]=trim(val); name.clear(); val.clear(); };
  while(std::getline(is,line)){ if(!line.empty()&&line.back()=='\r')line.pop_back();
    if(!line.empty()&&(line[0]==' '||line[0]=='\t')) val+=" "+trim(line);
    else{ flush(); auto c=line.find(':'); if(c==NP)continue; name=lower(line.substr(0,c)); val=line.substr(c+1); } }
  flush(); return m; }
static std::string strip_html(const std::string& h){ std::string o,lo=lower(h); size_t i=0;
  while(i<h.size()){
    if(h[i]=='<'){ bool sk=false;
      for(auto t:{"style","script"}){ if(lo.compare(i+1,strlen(t),t)==0){ size_t e=lo.find(std::string("</")+t,i); if(e!=NP){ size_t g=lo.find('>',e); i=(g==NP)?h.size():g+1; sk=true; break; } } }
      if(!sk){ size_t e=h.find('>',i); std::string tg=lo.substr(i+1,3);
        if(tg=="br "||tg=="br/"||tg=="br>"||tg[0]=='p'||tg=="/p>"||tg=="/di")o+='\n'; i=(e==NP)?h.size():e+1; } }
    else o+=h[i++]; }
  for(auto& r:std::vector<std::pair<std::string,std::string>>{{"&nbsp;"," "},{"&lt;","<"},{"&gt;",">"},{"&quot;","\""},{"&#39;","'"},{"&amp;","&"}})
    for(size_t p=0;(p=o.find(r.first,p))!=NP;p+=r.second.size())o.replace(p,r.first.size(),r.second);
  return o; }
struct Att{ std::string name,mime,cid,data; };
struct Parsed{ std::string text,html; std::vector<Att> atts; size_t bytes=0; };
// Header parameter lookup, including RFC 2231 (filename*=UTF-8''...) and RFC 2047 encoded words.
static std::string hparam(const std::string& hv,const std::string& key){ std::string l=lower(hv);
  size_t p=l.find(key+"*="); while(p!=NP&&p>0&&l[p-1]!=';'&&l[p-1]!=' '&&l[p-1]!='\t')p=l.find(key+"*=",p+1);
  if(p!=NP){ size_t st=p+key.size()+2,e=hv.find(';',st); std::string v=trim(hv.substr(st,e==NP?NP:e-st)); size_t q1=v.find('\''),q2=q1==NP?NP:v.find('\'',q1+1);
    if(q2!=NP){ std::string raw=v.substr(q2+1),o; for(size_t k=0;k<raw.size();++k){ if(raw[k]=='%'&&k+2<raw.size()&&isxdigit((unsigned char)raw[k+1])&&isxdigit((unsigned char)raw[k+2])){ o+=(char)std::stoi(raw.substr(k+1,2),nullptr,16); k+=2; } else o+=raw[k]; } return to_utf8(o,v.substr(0,q1)); } }
  p=l.find(key+"="); while(p!=NP&&p>0&&l[p-1]!=';'&&l[p-1]!=' '&&l[p-1]!='\t')p=l.find(key+"=",p+1);
  if(p==NP)return ""; std::string v=hv.substr(p+key.size()+1);
  if(!v.empty()&&v[0]=='"'){ v=v.substr(1); v=v.substr(0,v.find('"')); } else v=trim(v.substr(0,v.find(';')));
  return decode_words(v); }
static std::string strip_ang(std::string s){ s=trim(s); if(!s.empty()&&s.front()=='<')s.erase(0,1); if(!s.empty()&&s.back()=='>')s.pop_back(); return s; }
static void walk(const std::string& raw,Parsed& out,int depth){
  std::string h,b; split(raw,h,b); auto H=hdrs(h);
  std::string ctr=H.count("content-type")?H["content-type"]:"text/plain",ct=lower(ctr),cte=H.count("content-transfer-encoding")?lower(H["content-transfer-encoding"]):"",disp=H.count("content-disposition")?H["content-disposition"]:"";
  if(ct.rfind("multipart/",0)==0){ if(depth>=8)return; auto p=ct.find("boundary="); if(p==NP)return;
    std::string bnd=ctr.substr(p+9); if(!bnd.empty()&&bnd[0]=='"'){ bnd=bnd.substr(1); bnd=bnd.substr(0,bnd.find('"')); } else bnd=bnd.substr(0,bnd.find_first_of("; \t\r\n"));
    std::string d="--"+bnd; size_t pos=b.find(d);
    while(pos!=NP){ if(b.compare(pos+d.size(),2,"--")==0)break; size_t ls=b.find('\n',pos); if(ls==NP)break;
      size_t nx=b.find("\n"+d,ls); walk(b.substr(ls+1,nx==NP?NP:nx-ls),out,depth+1); pos=(nx==NP)?NP:nx+1; }
    return; }
  std::string name=hparam(disp,"filename"); if(name.empty())name=hparam(ctr,"name");
  bool attach=lower(disp).rfind("attachment",0)==0||!name.empty();
  std::string body=cte=="base64"?b64dec(b):cte=="quoted-printable"?qpdec(b):b;
  bool isHtml=ct.rfind("text/html",0)==0;
  if(!attach&&(isHtml||ct.rfind("text/plain",0)==0)){
    static const std::regex cr(R"(charset="?([^;\s"]+))",std::regex::icase); std::smatch m; std::string cs="utf-8"; if(std::regex_search(ctr,m,cr))cs=m[1].str();
    body=to_utf8(body,cs); if(isHtml){ if(out.html.empty())out.html=body; } else if(out.text.empty())out.text=body; return; }
  if(out.bytes>30000000||body.size()>15000000)return;
  std::string mime=trim(ct.substr(0,ct.find(';'))),cid=strip_ang(H.count("content-id")?H["content-id"]:"");
  if(name.empty()){ name=cid.empty()?"attachment":"inline-"+cid; size_t sl=mime.find('/'); if(sl!=NP&&mime.rfind("image/",0)==0)name+="."+mime.substr(sl+1); }
  out.bytes+=body.size(); out.atts.push_back({name,mime,cid,body}); }
static std::string pct(const std::string& s){ static const char* hx="0123456789ABCDEF"; std::string o; for(unsigned char c:s){ if(isalnum(c)||c=='-'||c=='_'||c=='.'||c=='~')o+=(char)c; else{ o+='%'; o+=hx[c>>4]; o+=hx[c&15]; } } return o; }
static std::string ascii_name(const std::string& s){ std::string o; for(unsigned char c:s)o+=(c<0x20||c>0x7e||c=='"'||c=='\\'||c=='/')?'_':(char)c; return o.empty()?"file":o; }
static std::string clean_hdr(std::string s){ s.erase(std::remove_if(s.begin(),s.end(),[](char c){return c=='\r'||c=='\n';}),s.end()); return s; }
static std::string clean_mime(const std::string& s){ std::string o; for(char c:s)if(isalnum((unsigned char)c)||c=='/'||c=='+'||c=='.'||c=='-')o+=c; return o.find('/')==NP?"application/octet-stream":o; }
static long parse_date(const std::string& d){ struct tm tm{}; const char* p=strptime(d.c_str(),"%a, %d %b %Y %H:%M:%S",&tm); if(!p)p=strptime(d.c_str(),"%d %b %Y %H:%M:%S",&tm);
  if(!p)return (long)time(0); long t=(long)timegm(&tm); int tz=0; if(sscanf(p," %d",&tz)==1)t-=(tz/100)*3600+(tz%100)*60; return t; }
struct Msg{ std::string from,subject,body,html; long ts; std::vector<Att> atts; };
static Msg parse_msg(const std::string& raw){ std::string h,b; split(raw,h,b); auto H=hdrs(h); Msg m;
  m.from=decode_words(H["from"]); m.subject=decode_words(H["subject"]); m.ts=parse_date(H["date"]);
  Parsed P; walk(raw,P,0); m.body=trim(P.text.empty()?strip_html(P.html):P.text); m.html=std::move(P.html); m.atts=std::move(P.atts);
  if(m.body.size()>200000)m.body.resize(200000); if(m.html.size()>1000000)m.html.clear(); return m; }
static void add_atts(long long mid,const std::vector<Att>& v){ std::lock_guard<std::mutex> l(dbm);
  for(auto& a:v){ sqlite3_stmt* st; if(sqlite3_prepare_v2(db,"INSERT INTO attachments(mail_id,name,mime,cid,size,data) VALUES(?,?,?,?,?,?)",-1,&st,0)!=SQLITE_OK)return;
    sqlite3_bind_int64(st,1,mid); sqlite3_bind_text(st,2,a.name.c_str(),-1,SQLITE_TRANSIENT); sqlite3_bind_text(st,3,a.mime.c_str(),-1,SQLITE_TRANSIENT); sqlite3_bind_text(st,4,a.cid.c_str(),-1,SQLITE_TRANSIENT);
    sqlite3_bind_int64(st,5,(long long)a.data.size()); sqlite3_bind_blob(st,6,a.data.data(),(int)a.data.size(),SQLITE_TRANSIENT); sqlite3_step(st); sqlite3_finalize(st); } }
static bool get_att(long long id,Att& a){ std::lock_guard<std::mutex> l(dbm); sqlite3_stmt* st; if(sqlite3_prepare_v2(db,"SELECT name,mime,cid,data FROM attachments WHERE id=?",-1,&st,0)!=SQLITE_OK)return false;
  sqlite3_bind_int64(st,1,id); bool ok=false;
  if(sqlite3_step(st)==SQLITE_ROW){ auto t=[&](int c){ auto p=sqlite3_column_text(st,c); return std::string(p?(const char*)p:""); }; a.name=t(0); a.mime=t(1); a.cid=t(2);
    int n=sqlite3_column_bytes(st,3); a.data.assign(n>0?(const char*)sqlite3_column_blob(st,3):"",n>0?(size_t)n:0); ok=true; }
  sqlite3_finalize(st); return ok; }

// ---------- IMAP / SMTP ----------
struct Acc{ long long id; std::string email,pass,ih,sh; int ip,sp,tls; };
static Acc to_acc(const json& r){ Acc a; a.id=r["id"]; a.email=r["email"].get<std::string>(); a.pass=r["pass"].get<std::string>(); a.ih=r["ih"].get<std::string>();
  a.sh=r["sh"].get<std::string>(); a.ip=r["ip"]; a.sp=r["sp"]; a.tls=r["tls"]; return a; }
static size_t wcb(char* p,size_t s,size_t n,void* u){ ((std::string*)u)->append(p,s*n); return s*n; }
// TLS trust store: Android has no system OpenSSL paths, so the app ships a CA bundle (cacert.pem) and points POCT_CA at it.
static void curl_common(CURL* c){ const char* ca=getenv("POCT_CA"); if(!ca&&access("cacert.pem",R_OK)==0)ca="cacert.pem"; if(ca)curl_easy_setopt(c,CURLOPT_CAINFO,ca); }
static std::string nice_err(CURLcode rc,const char* eb){ if(rc==CURLE_LOGIN_DENIED)return "wrong email or password (Gmail/Yahoo need an app password)";
  if(rc==CURLE_COULDNT_RESOLVE_HOST)return "server not found, check the address"; if(rc==CURLE_COULDNT_CONNECT||rc==CURLE_OPERATION_TIMEDOUT)return "could not connect to the server (check port/internet)";
  std::string e=eb[0]?eb:curl_easy_strerror(rc); e.erase(std::remove_if(e.begin(),e.end(),[](unsigned char c){return c<32;}),e.end()); return e; }
static bool imap_do(const Acc& a,const std::string& path,const char* custom,std::string& out,std::string& err){
  CURL* c=curl_easy_init(); curl_common(c); char eb[CURL_ERROR_SIZE]={0}; out.clear();
  std::string url=std::string(a.tls?"imaps://":"imap://")+a.ih+":"+std::to_string(a.ip)+"/"+path;
  curl_easy_setopt(c,CURLOPT_URL,url.c_str()); curl_easy_setopt(c,CURLOPT_USERNAME,a.email.c_str()); curl_easy_setopt(c,CURLOPT_PASSWORD,a.pass.c_str());
  curl_easy_setopt(c,CURLOPT_WRITEFUNCTION,wcb); curl_easy_setopt(c,CURLOPT_WRITEDATA,&out); curl_easy_setopt(c,CURLOPT_ERRORBUFFER,eb);
  curl_easy_setopt(c,CURLOPT_TIMEOUT,45L); curl_easy_setopt(c,CURLOPT_CONNECTTIMEOUT,10L);
  if(custom)curl_easy_setopt(c,CURLOPT_CUSTOMREQUEST,custom);
  CURLcode rc=curl_easy_perform(c); curl_easy_cleanup(c);
  if(rc){ err=nice_err(rc,eb); return false; } return true; }
static std::vector<long long> parse_uids(const std::string& out){ std::vector<long long> v; auto p=out.find("SEARCH"); if(p==NP)return v;
  std::istringstream is(out.substr(p+6,out.find('\n',p)-p-6)); long long x; while(is>>x)v.push_back(x); return v; }
static void sync_account(const Acc& a){
  long long last=q("SELECT last_uid FROM accounts WHERE id=?",{std::to_string(a.id)})[0]["last_uid"];
  std::string out,err,cmd=last?"UID SEARCH UID "+std::to_string(last+1)+":*":"UID SEARCH ALL";
  if(!imap_do(a,"INBOX",cmd.c_str(),out,err)){ push_event({{"type","error"},{"account",a.email},{"error",err}}); return; }
  auto u=parse_uids(out); std::vector<long long> nw; for(auto x:u)if(x>last)nw.push_back(x);
  std::sort(nw.begin(),nw.end()); if(nw.size()>50)nw.erase(nw.begin(),nw.end()-50);
  int added=0; const bool initial=(last==0);   // the first sync downloads history: no notifications for it
  for(auto uid:nw){ std::string raw; if(!imap_do(a,"INBOX/;UID="+std::to_string(uid),nullptr,raw,err))continue;
    Msg m=parse_msg(raw); q("INSERT OR IGNORE INTO mails(account_id,folder,uid,sender,subject,body,html,ts) VALUES(?,'inbox',?,?,?,?,?,?)",
      {std::to_string(a.id),std::to_string(uid),m.from,m.subject,m.body,m.html,std::to_string(m.ts)});
    if(!m.atts.empty()){ auto r=q("SELECT id,(SELECT COUNT(*) FROM attachments WHERE mail_id=mails.id) n FROM mails WHERE account_id=? AND folder='inbox' AND uid=?",{std::to_string(a.id),std::to_string(uid)});
      if(!r.empty()&&r[0]["n"].get<long long>()==0)add_atts(r[0]["id"].get<long long>(),m.atts); }
    added++; if(!initial&&added<=5)push_event({{"type","new_mail"},{"account",a.email},{"from",m.from},{"subject",m.subject}}); }
  if(!u.empty()){ long long mx=*std::max_element(u.begin(),u.end()); if(mx>last)q("UPDATE accounts SET last_uid=? WHERE id=?",{std::to_string(mx),std::to_string(a.id)}); }
  push_event({{"type","synced"},{"account",a.email},{"added",added}});
}
static std::mutex wm; static std::condition_variable wcv; static bool wake=false;
static void wake_sync(){ { std::lock_guard<std::mutex> l(wm); wake=true; } wcv.notify_all(); }
static void sync_loop(){ for(;;){ { std::unique_lock<std::mutex> l(wm); wcv.wait_for(l,std::chrono::seconds(env_secs("POCT_SYNC_SECS",30)),[]{return wake;}); wake=false; }
  for(auto& r:q("SELECT * FROM accounts"))sync_account(to_acc(r)); } }
struct Up{ std::string d; size_t pos=0; };
static size_t rcb(char* p,size_t s,size_t n,void* u){ auto* x=(Up*)u; size_t k=std::min(s*n,x->d.size()-x->pos); memcpy(p,x->d.data()+x->pos,k); x->pos+=k; return k; }
static std::string rand_hex(size_t n);
// Splits a recipient list; returns false if any non-empty entry is not a plain address (blocks header-injection tricks too).
static bool addrs(const std::string& s,std::vector<std::string>& v){ std::string cur; bool good=true;
  auto flush=[&]{ std::string t=trim(cur); cur.clear(); if(t.empty())return; auto lt=t.find('<'),gt=t.find('>'); if(lt!=NP&&gt!=NP&&gt>lt)t=trim(t.substr(lt+1,gt-lt-1));
    if(t.find('@')!=NP&&t.find_first_of(" \r\n<>\"")==NP)v.push_back(t); else good=false; };
  for(char c:s){ if(c==','||c==';')flush(); else cur+=c; } flush(); return good; }
static std::string build_mime(const Acc& a,const std::string& to,const std::string& cc,const std::string& subj,const std::string& text,const std::string& html,const std::vector<Att>& atts){
  char date[64]; time_t t=time(0); struct tm g; gmtime_r(&t,&g); strftime(date,64,"%a, %d %b %Y %H:%M:%S +0000",&g);
  std::string H=std::string("Date: ")+date+"\r\nFrom: <"+a.email+">\r\nTo: "+clean_hdr(to)+"\r\n"+(trim(cc).empty()?"":"Cc: "+clean_hdr(cc)+"\r\n")+
    "Subject: =?UTF-8?B?"+b64enc(subj)+"?=\r\nMessage-ID: <"+rand_hex(12)+"@"+a.email.substr(a.email.find('@')+1)+">\r\nMIME-Version: 1.0\r\n";
  auto part=[&](const std::string& ct,const std::string& body){ return "Content-Type: "+ct+"; charset=utf-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"+b64enc(body,true)+"\r\n"; };
  std::string alt="alt_"+rand_hex(8),mix="mix_"+rand_hex(8),inner;
  if(html.empty())inner=part("text/plain",text);
  else inner="Content-Type: multipart/alternative; boundary=\""+alt+"\"\r\n\r\n--"+alt+"\r\n"+part("text/plain",text)+"--"+alt+"\r\n"+part("text/html",html)+"--"+alt+"--\r\n";
  if(atts.empty())return H+inner;
  std::string o=H+"Content-Type: multipart/mixed; boundary=\""+mix+"\"\r\n\r\n--"+mix+"\r\n"+inner;
  auto mparam=[&](const std::string& key,const std::string& name){ bool ascii=true; for(unsigned char c:name)if(c<0x20||c>0x7e)ascii=false;   // non-ASCII names: RFC 2231 only, so every client picks the real name
    return ascii?key+"=\""+ascii_name(name)+"\"":key+"*=UTF-8''"+pct(name); };
  for(auto& at:atts)o+="--"+mix+"\r\nContent-Type: "+at.mime+"; "+mparam("name",at.name)+"\r\nContent-Disposition: attachment; "+mparam("filename",at.name)+
    "\r\nContent-Transfer-Encoding: base64\r\n\r\n"+b64enc(at.data,true)+"\r\n";
  return o+"--"+mix+"--\r\n"; }
static bool smtp_send_raw(const Acc& a,const std::vector<std::string>& rcpts,const std::string& raw,std::string& err){
  Up up; up.d=raw;
  CURL* c=curl_easy_init(); curl_common(c); char eb[CURL_ERROR_SIZE]={0}; struct curl_slist* rc=nullptr;
  std::string url=std::string(a.sp==465?"smtps://":"smtp://")+a.sh+":"+std::to_string(a.sp);
  for(auto& r:rcpts)rc=curl_slist_append(rc,("<"+r+">").c_str());
  curl_easy_setopt(c,CURLOPT_URL,url.c_str()); curl_easy_setopt(c,CURLOPT_USERNAME,a.email.c_str()); curl_easy_setopt(c,CURLOPT_PASSWORD,a.pass.c_str());
  if(a.tls&&a.sp!=465)curl_easy_setopt(c,CURLOPT_USE_SSL,(long)CURLUSESSL_ALL);
  curl_easy_setopt(c,CURLOPT_MAIL_FROM,("<"+a.email+">").c_str()); curl_easy_setopt(c,CURLOPT_MAIL_RCPT,rc);
  curl_easy_setopt(c,CURLOPT_READFUNCTION,rcb); curl_easy_setopt(c,CURLOPT_READDATA,&up); curl_easy_setopt(c,CURLOPT_UPLOAD,1L);
  curl_easy_setopt(c,CURLOPT_ERRORBUFFER,eb); curl_easy_setopt(c,CURLOPT_TIMEOUT,300L); curl_easy_setopt(c,CURLOPT_CONNECTTIMEOUT,15L);
  CURLcode res=curl_easy_perform(c); curl_slist_free_all(rc); curl_easy_cleanup(c);
  if(res){ err=nice_err(res,eb); return false; } return true; }
static void preset(const std::string& d,std::string& ih,int& ip,std::string& sh,int& sp){ ip=993; sp=465; ih="imap."+d; sh="smtp."+d;
  if(d=="gmail.com"||d=="googlemail.com"){ ih="imap.gmail.com"; sh="smtp.gmail.com"; }
  else if(d=="outlook.com"||d=="hotmail.com"||d=="live.com"||d=="msn.com"){ ih="outlook.office365.com"; sh="smtp.office365.com"; sp=587; }
  else if(d=="yahoo.com"){ ih="imap.mail.yahoo.com"; sh="smtp.mail.yahoo.com"; }
  else if(d=="icloud.com"||d=="me.com"){ ih="imap.mail.me.com"; sh="smtp.mail.me.com"; sp=587; }
  else if(d=="yandex.com"||d=="yandex.ru"){ ih="imap.yandex.com"; sh="smtp.yandex.com"; }
  else if(d=="mail.ru"){ ih="imap.mail.ru"; sh="smtp.mail.ru"; } }

// ---------- Crypto (libsodium: X25519 + XSalsa20-Poly1305 boxes, Ed25519 signatures) ----------
static std::string hexs(const std::string& b){ std::string o(b.size()*2+1,'\0'); sodium_bin2hex(o.data(),o.size(),(const unsigned char*)b.data(),b.size()); o.resize(b.size()*2); return o; }
static std::string unhex(const std::string& h){ std::string o(h.size()/2,'\0'); size_t l=0;
  if(h.empty()||sodium_hex2bin((unsigned char*)o.data(),o.size(),h.c_str(),h.size(),0,&l,0)!=0)return ""; o.resize(l); return o; }
static std::string sign_b(const std::string& msg,const std::string& sk){ unsigned char s[crypto_sign_BYTES];
  crypto_sign_detached(s,nullptr,(const unsigned char*)msg.data(),msg.size(),(const unsigned char*)sk.data()); return std::string((char*)s,sizeof s); }
static bool verify_b(const std::string& msg,const std::string& sig,const std::string& pk){
  return sig.size()==crypto_sign_BYTES&&pk.size()==crypto_sign_PUBLICKEYBYTES&&
    crypto_sign_verify_detached((const unsigned char*)sig.data(),(const unsigned char*)msg.data(),msg.size(),(const unsigned char*)pk.data())==0; }
static std::string seal(const std::string& plain,const std::string& rpk,const std::string& ssk,const std::string& spk){
  unsigned char n[crypto_box_NONCEBYTES]; randombytes_buf(n,sizeof n); std::string c(plain.size()+crypto_box_MACBYTES,'\0');
  if(crypto_box_easy((unsigned char*)c.data(),(const unsigned char*)plain.data(),plain.size(),n,(const unsigned char*)rpk.data(),(const unsigned char*)ssk.data())!=0)return "";
  return b64enc(std::string((char*)n,sizeof n)+spk+c); }
static bool unseal(const std::string& blob,const std::string& rsk,std::string& spk,std::string& plain){
  std::string d=b64dec(blob); size_t hdr=crypto_box_NONCEBYTES+crypto_box_PUBLICKEYBYTES; if(d.size()<hdr+crypto_box_MACBYTES)return false;
  spk=d.substr(crypto_box_NONCEBYTES,crypto_box_PUBLICKEYBYTES); std::string c=d.substr(hdr); plain.assign(c.size()-crypto_box_MACBYTES,'\0');
  return crypto_box_open_easy((unsigned char*)plain.data(),(const unsigned char*)c.data(),c.size(),(const unsigned char*)d.data(),(const unsigned char*)spk.data(),(const unsigned char*)rsk.data())==0; }
static std::string fingerprint(const std::string& bpk_hex,const std::string& spk_hex){ unsigned char h[32]; std::string in=unhex(bpk_hex)+unhex(spk_hex);
  crypto_generichash(h,sizeof h,(const unsigned char*)in.data(),in.size(),nullptr,0); std::string x=hexs(std::string((char*)h,32)).substr(0,30),o;
  for(size_t i=0;i<x.size();i+=5){ if(i)o+=' '; o+=x.substr(i,5); } return o; }
static std::string rand_hex(size_t n){ std::string b(n,'\0'); randombytes_buf(b.data(),n); return hexs(b); }

// ---------- Small HTTP client + addressing ----------
static long http(const std::string& method,const std::string& url,const std::vector<std::string>& hd,const std::string& body,std::string& out){
  CURL* c=curl_easy_init(); curl_common(c); struct curl_slist* h=nullptr; for(auto& x:hd)h=curl_slist_append(h,x.c_str()); out.clear();
  curl_easy_setopt(c,CURLOPT_URL,url.c_str()); curl_easy_setopt(c,CURLOPT_CUSTOMREQUEST,method.c_str());
  if(method!="GET"){ curl_easy_setopt(c,CURLOPT_POSTFIELDS,body.c_str()); curl_easy_setopt(c,CURLOPT_POSTFIELDSIZE,(long)body.size()); }
  curl_easy_setopt(c,CURLOPT_HTTPHEADER,h); curl_easy_setopt(c,CURLOPT_WRITEFUNCTION,wcb); curl_easy_setopt(c,CURLOPT_WRITEDATA,&out);
  curl_easy_setopt(c,CURLOPT_TIMEOUT,60L); curl_easy_setopt(c,CURLOPT_CONNECTTIMEOUT,20L);   // free hosts may need ~50 s to wake up
  CURLcode rc=curl_easy_perform(c); long code=0; curl_easy_getinfo(c,CURLINFO_RESPONSE_CODE,&code);
  curl_slist_free_all(h); curl_easy_cleanup(c); return rc?-1:code; }
static std::string host_of(const std::string& url){ auto p=url.find("://"); std::string h=p==NP?url:url.substr(p+3); while(!h.empty()&&h.back()=='/')h.pop_back(); return h; }
static bool is_local(const std::string& host){ return host.rfind("127.",0)==0||host.rfind("localhost",0)==0; }
static std::string url_for_host(const std::string& host){ return std::string(is_local(host)?"http://":"https://")+host; }
static bool valid_handle(const std::string& h){ if(h.size()<3||h.size()>32)return false; for(char c:h)if(!(islower((unsigned char)c)||isdigit((unsigned char)c)||c=='_'))return false; return true; }
static bool split_addr(const std::string& a,std::string& handle,std::string& host){ auto at=a.find('@'); if(at==NP)return false; handle=a.substr(0,at); host=a.substr(at+1);
  if(!valid_handle(handle)||host.empty()||host.size()>255)return false; for(char c:host)if(!(isalnum((unsigned char)c)||c=='.'||c=='-'||c==':'))return false; return true; }

// ---------- Relay server (stores only ciphertext) ----------
static std::mutex rlm; static std::map<std::string,std::deque<time_t>> rl;
static bool rate_ok(const std::string& key,int mx,int secs){ std::lock_guard<std::mutex> l(rlm); auto& d=rl[key]; time_t n=time(0);
  while(!d.empty()&&d.front()<=n-secs)d.pop_front(); if((int)d.size()>=mx)return false; d.push_back(n); return true; }
static std::string client_ip(const httplib::Request& rq){ auto x=rq.get_header_value("X-Forwarded-For"); if(!x.empty())return trim(x.substr(0,x.find(','))); return rq.remote_addr; }
static void rjs(httplib::Response& r,const json& j,int st=200){ r.status=st; r.set_content(J(j),"application/json"); }
static bool relay_auth(const httplib::Request& rq,std::string& handle){ handle=rq.get_header_value("X-Handle"); std::string ts=rq.get_header_value("X-Ts"),sig=b64dec(rq.get_header_value("X-Sig"));
  if(handle.empty()||ts.empty())return false; if(labs(atol(ts.c_str())-(long)time(0))>300)return false;
  auto r=q("SELECT sign_pk FROM r_users WHERE handle=?",{handle}); if(r.empty())return false;
  return verify_b(ts+"\n"+rq.method+" "+rq.path+"\n"+rq.body,sig,unhex(r[0]["sign_pk"].get<std::string>())); }
static void run_relay(int port){
  httplib::Server s; s.set_payload_max_length(131072);
  s.set_exception_handler([](const httplib::Request&,httplib::Response& r,std::exception_ptr){ rjs(r,{{"error","Bad request"}},400); });
  s.Get("/",[](auto&,auto& rs){ rs.set_content("poct relay: end-to-end encrypted message relay. Use the Mail app to connect.\n","text/plain"); });
  s.Get("/relay/health",[](auto&,auto& rs){ const char* iv=getenv("POCT_INVITE"); rjs(rs,{{"ok",true},{"service","poct-relay"},{"invite_required",(bool)(iv&&iv[0])}}); });
  s.Post("/relay/register",[](const httplib::Request& rq,httplib::Response& rs){
    if(!rate_ok("reg:"+client_ip(rq),10,3600)){ rjs(rs,{{"error","Too many requests, try again later"}},429); return; }
    json j=json::parse(rq.body,nullptr,false); if(!j.is_object()){ rjs(rs,{{"error","Bad request"}},400); return; }
    std::string inv=getenv("POCT_INVITE")?getenv("POCT_INVITE"):""; if(!inv.empty()&&j.value("invite","")!=inv){ rjs(rs,{{"error","Invalid invite code"}},403); return; }
    std::string h=j.value("handle",""),bpk=j.value("box_pk",""),spk=j.value("sign_pk",""),sig=j.value("sig","");
    if(!valid_handle(h)){ rjs(rs,{{"error","Username must be 3-32 characters: a-z, 0-9 and _"}},400); return; }
    if(unhex(bpk).size()!=32||unhex(spk).size()!=32){ rjs(rs,{{"error","Bad public keys"}},400); return; }
    if(!verify_b("register:"+h+bpk,b64dec(sig),unhex(spk))){ rjs(rs,{{"error","Bad signature"}},400); return; }
    auto ex=q("SELECT sign_pk FROM r_users WHERE handle=?",{h});
    if(!ex.empty()){ if(ex[0]["sign_pk"].get<std::string>()==spk){ rjs(rs,{{"ok",true},{"existed",true}}); } else rjs(rs,{{"error","That username is already taken"}},409); return; }
    q("INSERT INTO r_users(handle,box_pk,sign_pk,created) VALUES(?,?,?,?)",{h,bpk,spk,std::to_string((long)time(0))}); rjs(rs,{{"ok",true}}); });
  s.Get(R"(/relay/key/([a-z0-9_]+))",[](const httplib::Request& rq,httplib::Response& rs){
    auto r=q("SELECT handle,box_pk,sign_pk FROM r_users WHERE handle=?",{rq.matches[1]}); if(r.empty()){ rjs(rs,{{"error","No such user"}},404); return; } rjs(rs,r[0]); });
  s.Post(R"(/relay/send/([a-z0-9_]+))",[](const httplib::Request& rq,httplib::Response& rs){
    if(!rate_ok("send:"+client_ip(rq),120,60)){ rjs(rs,{{"error","Rate limit exceeded"}},429); return; }
    json j=json::parse(rq.body,nullptr,false); if(!j.is_object()||!j.contains("blob")||!j["blob"].is_string()||j["blob"].get<std::string>().size()>65536){ rjs(rs,{{"error","Bad message"}},400); return; }
    std::string h=rq.matches[1]; if(q("SELECT 1 x FROM r_users WHERE handle=?",{h}).empty()){ rjs(rs,{{"error","No such user"}},404); return; }
    if(q("SELECT COUNT(*) n FROM r_box WHERE handle=?",{h})[0]["n"].get<long long>()>=2000){ rjs(rs,{{"error","Recipient mailbox is full"}},507); return; }
    q("INSERT INTO r_box(handle,blob,ts) VALUES(?,?,?)",{h,j["blob"].get<std::string>(),std::to_string((long)time(0))}); rjs(rs,{{"ok",true}}); });
  s.Get("/relay/inbox",[](const httplib::Request& rq,httplib::Response& rs){ std::string h; if(!relay_auth(rq,h)){ rjs(rs,{{"error","Unauthorized"}},401); return; }
    rjs(rs,q("SELECT id,blob,ts FROM r_box WHERE handle=? ORDER BY id LIMIT 100",{h})); });
  s.Post("/relay/ack",[](const httplib::Request& rq,httplib::Response& rs){ std::string h; if(!relay_auth(rq,h)){ rjs(rs,{{"error","Unauthorized"}},401); return; }
    json j=json::parse(rq.body,nullptr,false); if(j.is_object()&&j["ids"].is_array())for(auto& i:j["ids"])if(i.is_number_integer())q("DELETE FROM r_box WHERE handle=? AND id=?",{h,std::to_string(i.get<long long>())});
    rjs(rs,{{"ok",true}}); });
  std::thread([]{ for(;;){ q("DELETE FROM r_box WHERE ts<?",{std::to_string((long)time(0)-30*86400)}); std::this_thread::sleep_for(1h); } }).detach();
  printf("poct relay → 0.0.0.0:%d\n",port); fflush(stdout); s.listen("0.0.0.0",port);
}

// ---------- Chat client (runs inside the local engine; keys never leave this machine) ----------
struct Ident{ bool ok=false; std::string url,host,handle,box_sk,box_pk,sign_sk,sign_pk; };   // keys in binary
static std::string idget(const std::string& k){ auto r=q("SELECT v FROM identity WHERE k=?",{k}); return r.empty()?"":r[0]["v"].get<std::string>(); }
static void idset(const std::string& k,const std::string& v){ q("INSERT OR REPLACE INTO identity(k,v) VALUES(?,?)",{k,v}); }
static Ident ident(){ Ident i; i.handle=idget("handle"); if(i.handle.empty())return i; i.url=idget("relay_url"); i.host=host_of(i.url);
  i.box_sk=unhex(idget("box_sk")); i.box_pk=unhex(idget("box_pk")); i.sign_sk=unhex(idget("sign_sk")); i.sign_pk=unhex(idget("sign_pk"));
  i.ok=i.box_sk.size()==32&&i.sign_sk.size()==64; return i; }
static std::vector<std::string> auth_hdrs(const Ident& id,const std::string& method,const std::string& path,const std::string& body){
  std::string ts=std::to_string((long)time(0)); return {"X-Handle: "+id.handle,"X-Ts: "+ts,"X-Sig: "+b64enc(sign_b(ts+"\n"+method+" "+path+"\n"+body,id.sign_sk)),"Content-Type: application/json"}; }
static std::string register_body(const std::string& h,const std::string& bpk_hex,const std::string& spk_hex,const std::string& ssk,const std::string& invite){
  return J({{"handle",h},{"box_pk",bpk_hex},{"sign_pk",spk_hex},{"sig",b64enc(sign_b("register:"+h+bpk_hex,ssk))},{"invite",invite}}); }
struct Key{ std::string bpk,spk; };   // hex
// 1 = found, 0 = no such user, -1 = network problem. First sight of a key pins it (trust on first use).
static int lookup_key(const std::string& addr,Key& k,bool pin){
  auto r=q("SELECT box_pk,sign_pk FROM contacts WHERE addr=?",{addr}); if(!r.empty()){ k.bpk=r[0]["box_pk"].get<std::string>(); k.spk=r[0]["sign_pk"].get<std::string>(); return 1; }
  std::string h,host,out; if(!split_addr(addr,h,host))return 0;
  long c=http("GET",url_for_host(host)+"/relay/key/"+h,{},"",out); if(c==404)return 0; if(c!=200)return -1;
  json j=json::parse(out,nullptr,false); if(!j.is_object()||!j.contains("box_pk")||!j.contains("sign_pk"))return 0;
  k.bpk=j["box_pk"].get<std::string>(); k.spk=j["sign_pk"].get<std::string>(); if(unhex(k.bpk).size()!=32||unhex(k.spk).size()!=32)return 0;
  if(pin)q("INSERT OR REPLACE INTO contacts(addr,box_pk,sign_pk,first_seen) VALUES(?,?,?,?)",{addr,k.bpk,k.spk,std::to_string((long)time(0))}); return 1; }
static void chat_poll_once(){
  Ident id=ident(); if(!id.ok)return; std::string out;
  long c=http("GET",id.url+"/relay/inbox",auth_hdrs(id,"GET","/relay/inbox",""),"",out);
  if(c==401){ http("POST",id.url+"/relay/register",{"Content-Type: application/json"},register_body(id.handle,hexs(id.box_pk),hexs(id.sign_pk),id.sign_sk,idget("invite")),out); return; }  // relay lost its data (free hosts wipe disks): re-register same keys
  if(c!=200)return;
  json arr=json::parse(out,nullptr,false); if(!arr.is_array())return; json acks=json::array();
  for(auto& m:arr){ long long mid=m["id"].get<long long>(); std::string spk,pl;
    if(!unseal(m["blob"].get<std::string>(),id.box_sk,spk,pl)){ acks.push_back(mid); continue; }
    json e=json::parse(pl,nullptr,false); if(!e.is_object()){ acks.push_back(mid); continue; }
    std::string from=e.value("from",""),text=e.value("text",""),msgid=e.value("msgid",""); if(text.size()>8000)text.resize(8000);
    Key k; int lk=lookup_key(from,k,true); if(lk<0)continue;   // network trouble: keep it on the relay and retry
    if(lk==0||unhex(k.bpk)!=spk){ acks.push_back(mid); push_event({{"type","security"},{"peer",from},{"error",lk==0?"unknown sender":"sender key changed"}}); continue; }
    q("INSERT OR IGNORE INTO chats(peer,dir,body,ts,unread,msgid) VALUES(?,0,?,?,1,?)",{from,text,std::to_string(e.value("ts",(long long)time(0))),msgid});
    acks.push_back(mid); push_event({{"type","chat"},{"peer",from},{"text",utf8_trunc(text,200)}}); }
  if(!acks.empty()){ std::string body=J({{"ids",acks}}),o2; http("POST",id.url+"/relay/ack",auth_hdrs(id,"POST","/relay/ack",body),body,o2); }
}
static void outbox_flush(){
  for(auto& r:q("SELECT msgid,peer,blob,ts FROM outbox ORDER BY ts LIMIT 20")){
    std::string id=r["msgid"].get<std::string>(),peer=r["peer"].get<std::string>(),h,host,out; long long ts=r["ts"].get<long long>();
    auto done=[&](const char* st){ q("DELETE FROM outbox WHERE msgid=?",{id}); q("UPDATE chats SET state=? WHERE msgid=?",{st,id}); push_event({{"type","chat_state"},{"peer",peer}}); };
    if(time(0)-ts>7*86400||!split_addr(peer,h,host)){ done("2"); continue; }
    long c=http("POST",url_for_host(host)+"/relay/send/"+h,{"Content-Type: application/json"},J({{"blob",r["blob"].get<std::string>()}}),out);
    if(c==200)done("0"); else if(c!=-1&&c!=404&&c!=429&&c<500)done("2"); } }
static void chat_loop(){ time_t lastflush=0; for(;;){ chat_poll_once(); if(time(0)-lastflush>=9){ outbox_flush(); lastflush=time(0); } std::this_thread::sleep_for(std::chrono::seconds(env_secs("POCT_CHAT_SECS",3))); } }

// ---------- HTTP ----------
static std::string ftsq(const std::string& s){ std::istringstream is(s); std::string w,o; while(is>>w){ w.erase(std::remove(w.begin(),w.end(),'"'),w.end()); if(!w.empty())o+="\""+w+"\"* "; } return o; }
int MAIN_FN(int argc,char** argv){
  if(sodium_init()<0)return 1; umask(077);   // database (with private keys) is readable only by the owner
  bool relay=false; int port=0; std::string dbp;
  for(int i=1;i<argc;i++){ std::string a=argv[i]; if(a=="--relay")relay=true; else if(a=="--port"&&i+1<argc)port=atoi(argv[++i]); else if(a=="--db"&&i+1<argc)dbp=argv[++i]; }
  if(dbp.empty())dbp=getenv("POCT_DB")?getenv("POCT_DB"):(relay?"relay.db":"poct.db");
  if(!port)port=relay?(getenv("PORT")?atoi(getenv("PORT")):8080):(getenv("POCT_PORT")?atoi(getenv("POCT_PORT")):7878);
  curl_global_init(CURL_GLOBAL_DEFAULT); init_db(dbp.c_str());
  if(relay){ run_relay(port); return 0; }
  std::thread(sync_loop).detach(); std::thread(chat_loop).detach();
  httplib::Server svr; svr.set_payload_max_length(48u*1024*1024);   // 20 MB of attachments become ~27 MB of base64 JSON
  auto js=[](httplib::Response& r,const json& j,int st=200){ r.status=st; r.set_content(J(j),"application/json"); };
  svr.set_exception_handler([&](const httplib::Request&,httplib::Response& r,std::exception_ptr){ js(r,{{"error","Bad request"}},400); });
  const std::string COLS="m.id,m.account_id,m.folder,m.sender,m.subject,substr(m.body,1,160) snippet,(SELECT COUNT(*) FROM attachments a WHERE a.mail_id=m.id) att,m.ts,m.unread,m.starred";

  svr.Get("/api/accounts",[&](auto&,auto& rs){ js(rs,q("SELECT id,email,ih,sh FROM accounts ORDER BY id")); });
  svr.Post("/api/accounts",[&](const httplib::Request& rq,httplib::Response& rs){
    json j=json::parse(rq.body); Acc a; a.email=lower(trim(j.value("email",""))); a.pass=j.value("password","");
    auto at=a.email.find('@'); if(at==NP||a.pass.empty()){ js(rs,{{"error","Enter an email address and password"}},400); return; }
    preset(a.email.substr(at+1),a.ih,a.ip,a.sh,a.sp);
    if(j.contains("imap_host")&&!j["imap_host"].get<std::string>().empty())a.ih=j["imap_host"];
    if(j.contains("imap_port")&&j["imap_port"].is_number())a.ip=j["imap_port"];
    if(j.contains("smtp_host")&&!j["smtp_host"].get<std::string>().empty())a.sh=j["smtp_host"];
    if(j.contains("smtp_port")&&j["smtp_port"].is_number())a.sp=j["smtp_port"];
    a.tls=j.value("tls",true)?1:0; a.id=0; std::string out,err;
    if(!imap_do(a,"INBOX","UID SEARCH ALL",out,err)){ js(rs,{{"error","Could not connect: "+err}},400); return; }
    long long id=0; q("INSERT OR REPLACE INTO accounts(email,pass,ih,ip,sh,sp,tls) VALUES(?,?,?,?,?,?,?)",
      {a.email,a.pass,a.ih,std::to_string(a.ip),a.sh,std::to_string(a.sp),std::to_string(a.tls)},&id);
    wake_sync(); js(rs,{{"ok",true},{"id",id},{"email",a.email}}); });
  svr.Delete(R"(/api/accounts/(\d+))",[&](const httplib::Request& rq,httplib::Response& rs){
    q("DELETE FROM mails WHERE account_id=?",{rq.matches[1]}); q("DELETE FROM accounts WHERE id=?",{rq.matches[1]}); js(rs,{{"ok",true}}); });
  svr.Get("/api/messages",[&](const httplib::Request& rq,httplib::Response& rs){
    std::string f=rq.has_param("folder")?rq.get_param_value("folder"):"inbox",sql="SELECT "+COLS+" FROM mails m WHERE ";
    Args a; if(f=="starred")sql+="m.starred=1 AND m.folder!='trash'"; else{ sql+="m.folder=?"; a.push_back(f); }
    if(rq.has_param("account")&&!rq.get_param_value("account").empty()){ sql+=" AND m.account_id=?"; a.push_back(rq.get_param_value("account")); }
    js(rs,q(sql+" ORDER BY m.ts DESC,m.id DESC LIMIT 300",a)); });
  svr.Get("/api/search",[&](const httplib::Request& rq,httplib::Response& rs){
    auto f=ftsq(rq.get_param_value("q")); if(f.empty()){ js(rs,json::array()); return; }
    js(rs,q("SELECT "+COLS+" FROM mails_fts JOIN mails m ON m.id=mails_fts.rowid WHERE mails_fts MATCH ? AND m.folder!='trash' ORDER BY m.ts DESC LIMIT 100",{f})); });
  svr.Get(R"(/api/message/(\d+))",[&](const httplib::Request& rq,httplib::Response& rs){
    auto r=q("SELECT m.*,(SELECT email FROM accounts WHERE id=m.account_id) account FROM mails m WHERE id=?",{rq.matches[1]});
    if(r.empty()){ js(rs,{{"error","Not found"}},404); return; } q("UPDATE mails SET unread=0 WHERE id=?",{rq.matches[1]});
    json o=r[0]; o["attachments"]=q("SELECT id,name,mime,cid,size FROM attachments WHERE mail_id=? ORDER BY id",{rq.matches[1]}); js(rs,o); });
  svr.Post("/api/mark",[&](const httplib::Request& rq,httplib::Response& rs){ json j=json::parse(rq.body); std::string id=std::to_string(j.at("id").get<long long>());
    if(j.contains("unread"))q("UPDATE mails SET unread=? WHERE id=?",{j["unread"].get<bool>()?"1":"0",id});
    if(j.contains("starred"))q("UPDATE mails SET starred=? WHERE id=?",{j["starred"].get<bool>()?"1":"0",id});
    if(j.contains("folder")){ if(j["folder"]=="purge")q("DELETE FROM mails WHERE id=?",{id}); else q("UPDATE mails SET folder=? WHERE id=?",{j["folder"].get<std::string>(),id}); }
    js(rs,{{"ok",true}}); });
  svr.Get("/api/counts",[&](auto&,auto& rs){ js(rs,q("SELECT account_id,COUNT(*) n FROM mails WHERE folder='inbox' AND unread=1 GROUP BY account_id")); });
  svr.Post("/api/sync",[&](auto&,auto& rs){ wake_sync(); js(rs,{{"ok",true}}); });
  svr.Get(R"(/api/attachment/(\d+))",[&](const httplib::Request& rq,httplib::Response& rs){
    Att a; if(!get_att(std::stoll(rq.matches[1]),a)){ js(rs,{{"error","Not found"}},404); return; }
    static const std::set<std::string> img={"image/png","image/jpeg","image/gif","image/webp","image/bmp"};
    bool inl=rq.has_param("inline")&&img.count(a.mime); std::string ct=a.mime;
    if(!inl&&(ct.empty()||ct.rfind("text/html",0)==0||ct.find("xml")!=NP||ct.find("svg")!=NP))ct="application/octet-stream";
    rs.set_header("X-Content-Type-Options","nosniff"); rs.set_header("Content-Security-Policy","sandbox; default-src 'none'");   // an attachment can never run code inside the app
    rs.set_header("Content-Disposition",std::string(inl?"inline":"attachment")+"; filename=\""+ascii_name(a.name)+"\"; filename*=UTF-8''"+pct(a.name)); rs.set_content(a.data,ct); });
  svr.Post("/api/draft",[&](const httplib::Request& rq,httplib::Response& rs){ json j=json::parse(rq.body); long long id=j.value("id",0LL);
    Args v={std::to_string(j.value("account",0LL)),"Draft",j.value("subject",""),j.value("body",""),j.value("html",""),j.value("to",""),j.value("cc",""),std::to_string((long)time(0))};
    if(id>0&&!q("SELECT 1 x FROM mails WHERE id=? AND folder='drafts'",{std::to_string(id)}).empty()){ Args u=v; u.push_back(std::to_string(id));
      q("UPDATE mails SET account_id=?,sender=?,subject=?,body=?,html=?,to_addr=?,cc=?,ts=? WHERE id=?",u); js(rs,{{"id",id}}); return; }
    long long nid=0; q("INSERT INTO mails(account_id,folder,sender,subject,body,html,to_addr,cc,ts,unread) VALUES(?,'drafts',?,?,?,?,?,?,?,0)",v,&nid); js(rs,{{"id",nid}}); });
  svr.Post("/api/send",[&](const httplib::Request& rq,httplib::Response& rs){ json j=json::parse(rq.body);
    auto r=q("SELECT * FROM accounts WHERE id=?",{std::to_string(j.at("account").get<long long>())}); if(r.empty()){ js(rs,{{"error","Choose an account"}},400); return; }
    Acc a=to_acc(r[0]); std::string to=j.value("to",""),cc=j.value("cc",""),sub=clean_hdr(j.value("subject","")),body=j.value("body",""),html=j.value("html",""),err;
    std::vector<std::string> rc; bool okr=addrs(to,rc); okr=addrs(cc,rc)&&okr;
    if(!okr||rc.empty()){ js(rs,{{"error","Enter valid recipient addresses"}},400); return; }
    if(html.size()>2000000){ js(rs,{{"error","Message is too large"}},413); return; }
    std::vector<Att> atts; size_t total=0;
    if(j.contains("attachments")&&j["attachments"].is_array())for(auto& x:j["attachments"]){ Att at; at.name=x.value("name","file"); at.mime=clean_mime(x.value("mime","")); at.data=b64dec(x.value("data","")); total+=at.data.size(); atts.push_back(std::move(at)); }
    if(total>20000000){ js(rs,{{"error","Attachments are larger than 20 MB"}},413); return; }
    if(!smtp_send_raw(a,rc,build_mime(a,to,cc,sub,body,html,atts),err)){ js(rs,{{"error","Could not send: "+err}},502); return; }
    long long mid=0; q("INSERT INTO mails(account_id,folder,sender,subject,body,html,to_addr,cc,ts,unread) VALUES(?,'sent',?,?,?,?,?,?,?,0)",{std::to_string(a.id),"To: "+to,sub,body,html,to,cc,std::to_string((long)time(0))},&mid);
    add_atts(mid,atts); long long did=j.value("draft_id",0LL); if(did>0)q("DELETE FROM mails WHERE id=? AND folder='drafts'",{std::to_string(did)});
    js(rs,{{"ok",true}}); });
  svr.Get("/api/chat/probe",[&](const httplib::Request& rq,httplib::Response& rs){ std::string url=trim(rq.get_param_value("url")),out;
    if(url.empty()){ js(rs,{{"error","Enter the server address"}},400); return; }
    if(url.find("://")==NP)url=(is_local(url)?"http://":"https://")+url; while(!url.empty()&&url.back()=='/')url.pop_back();
    if(url.rfind("http://",0)==0&&!is_local(host_of(url))){ js(rs,{{"error","Use an https:// address (free hosts provide HTTPS automatically)"}},400); return; }
    long c=http("GET",url+"/relay/health",{},"",out);
    if(c==-1){ js(rs,{{"error","Could not reach the server. Free servers can take up to a minute to wake up, try again."}},502); return; }
    json h=json::parse(out,nullptr,false); if(c!=200||!h.is_object()||h.value("service","")!="poct-relay"){ js(rs,{{"error","That address is not a Mail chat server"}},400); return; }
    js(rs,{{"ok",true},{"invite_required",h.value("invite_required",false)}}); });
  svr.Get("/api/events",[](const httplib::Request&,httplib::Response& rs){
    auto last=std::make_shared<long>(0); { std::lock_guard<std::mutex> l(evm); *last=evseq; }
    rs.set_chunked_content_provider("text/event-stream",[last](size_t,httplib::DataSink& sink){
      std::unique_lock<std::mutex> l(evm);
      if(!evcv.wait_for(l,15s,[&]{return evseq>*last;})){ l.unlock(); return sink.write(": ping\n\n",8); }
      std::string o; for(auto& e:evs)if(e.first>*last)o+="data: "+e.second+"\n\n"; *last=evseq; l.unlock(); return sink.write(o.data(),o.size()); }); });
  svr.Get("/api/chat/identity",[&](auto&,auto& rs){ Ident i=ident(); if(!i.ok){ js(rs,{{"configured",false}}); return; }
    js(rs,{{"configured",true},{"address",i.handle+"@"+i.host},{"relay",i.url},{"fingerprint",fingerprint(hexs(i.box_pk),hexs(i.sign_pk))}}); });
  svr.Post("/api/chat/setup",[&](const httplib::Request& rq,httplib::Response& rs){
    if(ident().ok){ js(rs,{{"error","Chat is already set up"}},400); return; }
    json j=json::parse(rq.body); std::string url=trim(j.value("relay_url","")),h=lower(trim(j.value("handle",""))),inv=j.value("invite","");
    if(url.empty()){ js(rs,{{"error","Enter the server address"}},400); return; }
    if(url.find("://")==NP)url=(is_local(url)?"http://":"https://")+url; while(!url.empty()&&url.back()=='/')url.pop_back();
    if(url.rfind("http://",0)==0&&!is_local(host_of(url))){ js(rs,{{"error","Use an https:// address (free hosts provide HTTPS automatically)"}},400); return; }
    if(!valid_handle(h)){ js(rs,{{"error","Username must be 3-32 characters: a-z, 0-9 and _"}},400); return; }
    unsigned char bpk[crypto_box_PUBLICKEYBYTES],bsk[crypto_box_SECRETKEYBYTES],spk[crypto_sign_PUBLICKEYBYTES],ssk[crypto_sign_SECRETKEYBYTES];
    crypto_box_keypair(bpk,bsk); crypto_sign_keypair(spk,ssk);
    std::string B((char*)bpk,sizeof bpk),BS((char*)bsk,sizeof bsk),S((char*)spk,sizeof spk),SS((char*)ssk,sizeof ssk),out;
    long c=http("POST",url+"/relay/register",{"Content-Type: application/json"},register_body(h,hexs(B),hexs(S),SS,inv),out);
    if(c==-1){ js(rs,{{"error","Could not reach the server. Free servers can take up to a minute to wake up, try again."}},502); return; }
    if(c!=200){ json e=json::parse(out,nullptr,false); js(rs,{{"error",e.is_object()?e.value("error","Server refused the registration"):"Server refused the registration"}},400); return; }
    idset("relay_url",url); idset("handle",h); idset("invite",inv); idset("box_pk",hexs(B)); idset("box_sk",hexs(BS)); idset("sign_pk",hexs(S)); idset("sign_sk",hexs(SS));
    Ident i=ident(); js(rs,{{"ok",true},{"address",h+"@"+i.host}}); });
  svr.Get("/api/chat/lookup",[&](const httplib::Request& rq,httplib::Response& rs){ Key k; int r=lookup_key(lower(trim(rq.get_param_value("addr"))),k,true);
    if(r==1)js(rs,{{"ok",true},{"fingerprint",fingerprint(k.bpk,k.spk)}}); else if(r==0)js(rs,{{"error","No such user"}},404); else js(rs,{{"error","Could not reach that user's server"}},502); });
  svr.Post("/api/chat/reset_contact",[&](const httplib::Request& rq,httplib::Response& rs){ json j=json::parse(rq.body); q("DELETE FROM contacts WHERE addr=?",{j.value("addr","")}); js(rs,{{"ok",true}}); });
  svr.Get("/api/chat/threads",[&](auto&,auto& rs){ js(rs,q("SELECT peer,MAX(ts) ts,SUM(unread) unread,(SELECT body FROM chats c2 WHERE c2.peer=c.peer ORDER BY id DESC LIMIT 1) last FROM chats c GROUP BY peer ORDER BY MAX(id) DESC")); });
  svr.Get("/api/chat/messages",[&](const httplib::Request& rq,httplib::Response& rs){ std::string p=rq.get_param_value("peer");
    auto r=q("SELECT id,dir,body,ts,state FROM chats WHERE peer=? ORDER BY id LIMIT 500",{p}); q("UPDATE chats SET unread=0 WHERE peer=?",{p}); js(rs,r); });
  svr.Post("/api/chat/send",[&](const httplib::Request& rq,httplib::Response& rs){
    Ident i=ident(); if(!i.ok){ js(rs,{{"error","Chat is not set up yet"}},400); return; }
    json j=json::parse(rq.body); std::string to=lower(trim(j.value("to",""))),text=j.value("text",""),h,host,out;
    if(trim(text).empty()||text.size()>8000){ js(rs,{{"error","Message is empty or too long"}},400); return; }
    if(!split_addr(to,h,host)){ js(rs,{{"error","Enter an address like name@server.com"}},400); return; }
    if(to==i.handle+"@"+i.host){ js(rs,{{"error","You cannot message yourself"}},400); return; }
    Key k; int lk=lookup_key(to,k,true); if(lk==0){ js(rs,{{"error","No such user"}},404); return; } if(lk<0){ js(rs,{{"error","Could not reach the recipient's server"}},502); return; }
    std::string msgid=rand_hex(12); long ts=(long)time(0);
    std::string blob=seal(J({{"from",i.handle+"@"+i.host},{"msgid",msgid},{"ts",ts},{"text",text}}),unhex(k.bpk),i.box_sk,i.box_pk);
    long c=http("POST",url_for_host(host)+"/relay/send/"+h,{"Content-Type: application/json"},J({{"blob",blob}}),out);
    bool retry=(c==-1||c==404||c==429||c>=500);   // relay asleep, wiped, busy or down: keep the message and retry in the background
    if(c!=200&&!retry){ json e=json::parse(out,nullptr,false); js(rs,{{"error","Could not send: "+(e.is_object()?e.value("error","server error"):std::string("server unreachable"))}},502); return; }
    if(c!=200)q("INSERT OR IGNORE INTO outbox(msgid,peer,blob,ts) VALUES(?,?,?,?)",{msgid,to,blob,std::to_string(ts)});
    q("INSERT INTO chats(peer,dir,body,ts,unread,msgid,state) VALUES(?,1,?,?,0,?,?)",{to,text,std::to_string(ts),msgid,c==200?"0":"1"}); js(rs,{{"ok",true},{"queued",c!=200}}); });
  svr.set_mount_point("/",std::filesystem::exists("ui")?"ui":"../ui");
  printf("poct_core → http://127.0.0.1:%d\n",port); fflush(stdout);
  svr.listen("127.0.0.1",port);
  return 0;
}
