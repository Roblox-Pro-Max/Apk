"""End-to-end browser test. Run mock_mail_server.py and poct_core (POCT_PORT=7899) first."""
import json, urllib.request
from playwright.sync_api import sync_playwright
U = "http://127.0.0.1:7899"
def api(path, body=None, method=None):
    r = urllib.request.Request(U+path, data=json.dumps(body).encode() if body is not None else None, method=method)
    try: return json.load(urllib.request.urlopen(r))
    except urllib.error.HTTPError as e: return json.load(e)
ok = lambda name, cond: (print(("PASS  " if cond else "FAIL  ")+name), None)[1] or (_ for _ in ()).throw(AssertionError(name)) if not cond else print("PASS  "+name)
def nav(pg,f):
    pg.click(f"[data-f={f}]"); pg.wait_for_selector(f"[data-f={f}].on"); pg.wait_for_timeout(250)
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width":1280,"height":760}); errs=[]
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(U+"/"); pg.wait_for_selector(".welcome"); ok("empty state shows welcome", "Welcome to your mailbox" in pg.inner_text("#pane"))
    pg.click(".welcome .btn"); pg.fill("#ae","ui@mock.az"); pg.fill("#ap","bad"); pg.click("summary")
    pg.fill("#ih","127.0.0.1"); pg.fill("#ip","1143"); pg.fill("#sh","127.0.0.1"); pg.fill("#sp","1025"); pg.uncheck("#tls")
    pg.click("#ago"); pg.wait_for_function("document.querySelector('#aerr').textContent.length>0")
    ok("wrong password rejected in English", "wrong email or password" in pg.inner_text("#aerr"))
    pg.fill("#ap","good"); pg.click("#ago"); pg.wait_for_selector(".row", timeout=10000)
    pg.wait_for_function("document.querySelectorAll('.row').length===3 && document.querySelector('[data-f=inbox]').innerText.includes('3')", timeout=10000)
    ok("3 messages synced", pg.locator(".row").count()==3); ok("inbox unread badge = 3", pg.inner_text("[data-f=inbox]").split()[-1]=="3")
    ok("sidebar labels in English", all(t in pg.inner_text("aside") for t in ["Inbox","Starred","Sent","Trash","Compose","All accounts"]))
    pg.screenshot(path="/tmp/t/en_inbox.png")
    pg.click(".row >> nth=2"); pg.wait_for_selector(".msg"); ok("message opens", "Görüş" in pg.inner_text(".msg h1") and "15:00" in pg.inner_text(".msg pre"))
    pg.screenshot(path="/tmp/t/en_read.png")
    pg.click("#rep"); ok("reply prefilled", pg.input_value("#to")=="aysel@example.az" and pg.input_value("#sub").startswith("Re: ") and "wrote:" in pg.input_value("#body"))
    pg.fill("#body","Sounds good, see you there.\n"+pg.input_value("#body")); pg.screenshot(path="/tmp/t/en_compose.png"); pg.click("#send")
    pg.wait_for_selector("#win:not(.open)", state="attached"); pg.wait_for_function("document.querySelector('#toast').textContent=='Sent'")
    ok("send toast", True)
    nav(pg,"sent"); ok("sent folder has reply", "Re: Görüş" in pg.locator(".row .t").first.inner_text())
    nav(pg,"inbox"); pg.click(".row .star >> nth=0"); pg.wait_for_timeout(300); nav(pg,"starred")
    ok("star works", pg.locator(".row").count()==1)
    pg.fill("#q","gorus"); pg.wait_for_timeout(500); ok("diacritic-insensitive search", pg.locator(".row").count()==2)
    pg.fill("#q","zzzz"); pg.wait_for_timeout(500); ok("empty search message", "No results found." in pg.inner_text("#pane"))
    pg.fill("#q",""); pg.wait_for_timeout(400); nav(pg,"inbox"); pg.click(".row >> nth=0"); pg.wait_for_selector("#del"); pg.click("#del"); pg.wait_for_timeout(500)
    ok("delete moves to trash", pg.locator(".row").count()==2); nav(pg,"trash"); ok("trash has 1", pg.locator(".row").count()==1)
    pg.click(".row"); pg.wait_for_selector("#del"); ok("trash offers delete forever", pg.inner_text("#del")=="Delete forever"); pg.click("#del"); pg.wait_for_timeout(400)
    ok("purged", pg.locator(".row").count()==0 and "No messages" in pg.inner_text("#pane"))
    # second account + filtering
    r = api("/api/accounts", {"email":"two@mock.az","password":"good","imap_host":"127.0.0.1","imap_port":1143,"smtp_host":"127.0.0.1","smtp_port":1025,"tls":False}); ok("second account added via API", r.get("ok"))
    pg.wait_for_timeout(3500); pg.reload(); pg.wait_for_selector("#ac .n.sm >> nth=2"); ok("two accounts listed", pg.locator("#ac .n.sm").count()==3)
    pg.click("[data-a='2']"); pg.wait_for_timeout(400); ok("account filter shows only its mail", pg.locator(".row").count()==3)
    pg.click("[data-a='1']"); pg.wait_for_timeout(400); ok("first account has remaining 2", pg.locator(".row").count()==2)
    nav(pg,"sent"); ok("sent filtered by account", pg.locator(".row").count()==1)
    # mobile layout
    ok("no JS exceptions", errs==[]); b.close()
print("ALL UI TESTS PASSED")

# ---- mobile drawer test (separate context) ----
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width":390,"height":780}); pg.goto(U+"/"); pg.wait_for_selector(".row")
    ok("mobile: sidebar hidden, menu visible", pg.locator("#menu").is_visible() and not pg.locator("aside.open").count())
    pg.click("#menu"); pg.wait_for_timeout(300); pg.screenshot(path="/tmp/t/en_mobile_menu.png"); ok("mobile: drawer opens with Compose", pg.locator("#nc").is_visible())
    pg.click("[data-f=sent]"); pg.wait_for_selector("[data-f=sent].on"); ok("mobile: drawer closes after choosing a folder", pg.locator("aside.open").count()==0)
    pg.click("#menu"); pg.wait_for_timeout(300); pg.click("#nc"); ok("mobile: compose opens full width", pg.locator("#win.open").count()==1 and pg.locator("#win").bounding_box()["width"]>=380)
    b.close()
print("MOBILE TESTS PASSED")
