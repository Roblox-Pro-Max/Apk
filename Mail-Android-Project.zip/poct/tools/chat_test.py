"""End-to-end chat test: 2 relays, 4 engines. Usage: POCT_BIN=./build/poct_core python3 tools/chat_test.py (run from the folder containing ui/)."""
import json, os, sqlite3, subprocess, sys, tempfile, time, base64, urllib.request, urllib.error
BIN = os.environ.get("POCT_BIN", "./build/poct_core"); T = tempfile.mkdtemp(); procs = {}
def start(name, *args, env=None):
    e = dict(os.environ, **(env or {})); procs[name] = subprocess.Popen([BIN, *args], env=e, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
def stop(name): procs.pop(name).terminate()
def call(port, path, body=None, method=None, headers=None, raw=None):
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    r = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=data, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(r, timeout=70) as x: return x.status, json.loads(x.read() or b"null")
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read() or b"null")
        except Exception: return e.code, None
def wait(fn, t=12):
    end = time.time() + t
    while time.time() < end:
        try:
            v = fn()
            if v: return v
        except Exception: pass
        time.sleep(0.4)
    return None
n = 0
def ok(name, cond):
    global n; n += 1; print(("PASS  " if cond else "FAIL  ") + name)
    if not cond: raise AssertionError(name)
RA, RB, AL, BO, CA, DA = 9001, 9002, 7901, 7902, 7903, 7904
try:
    start("relayA", "--relay", "--port", str(RA), "--db", f"{T}/ra.db"); start("relayB", "--relay", "--port", str(RB), "--db", f"{T}/rb.db", env={"POCT_INVITE": "secret"})
    for nm, port in [("alice", AL), ("bob", BO), ("carol", CA), ("dave", DA)]:
        start(nm, "--db", f"{T}/{nm}.db", env={"POCT_PORT": str(port)})
    ok("relays and engines come up", all(wait(lambda p=p: call(p, "/relay/health")[0] == 200 if p in (RA, RB) else call(p, "/api/chat/identity")[0] == 200, 10) for p in (RA, RB, AL, BO, CA, DA)))
    ok("chat is not configured initially", call(AL, "/api/chat/identity")[1]["configured"] is False)
    # --- registration rules
    s, r = call(BO, "/api/chat/setup", {"relay_url": f"127.0.0.1:{RB}", "handle": "bob"}); ok("invite-only relay rejects missing invite", s == 400 and "invite" in r["error"].lower())
    s, r = call(BO, "/api/chat/setup", {"relay_url": f"127.0.0.1:{RB}", "handle": "bob", "invite": "secret"}); ok("valid invite registers bob", s == 200 and r["address"] == f"bob@127.0.0.1:{RB}")
    s, r = call(AL, "/api/chat/setup", {"relay_url": f"http://127.0.0.1:{RA}/", "handle": "alice"}); ok("alice registers on relay A", s == 200 and r["address"] == f"alice@127.0.0.1:{RA}")
    s, r = call(CA, "/api/chat/setup", {"relay_url": f"127.0.0.1:{RA}", "handle": "alice"}); ok("duplicate username rejected", s == 400 and "taken" in r["error"])
    s, r = call(CA, "/api/chat/setup", {"relay_url": f"127.0.0.1:{RA}", "handle": "A!"}); ok("invalid username rejected", s == 400)
    s, r = call(CA, "/api/chat/setup", {"relay_url": "http://example.com", "handle": "carol"}); ok("plain http to a public host refused", s == 400 and "https" in r["error"])
    s, r = call(CA, "/api/chat/setup", {"relay_url": "127.0.0.1:9", "handle": "carol"}); ok("unreachable server gives a clear error", s == 502)
    s, r = call(CA, "/api/chat/setup", {"relay_url": f"127.0.0.1:{RA}", "handle": "carol"}); ok("carol registers", s == 200)
    s, r = call(AL, "/api/chat/setup", {"relay_url": f"127.0.0.1:{RA}", "handle": "alice2"}); ok("identity cannot be overwritten", s == 400)
    # --- offline delivery + ciphertext only on the relay
    stop("bob"); time.sleep(0.5)
    TXT = "Salam Bob! Görüşərik, əla 你好 🔐 secret-plan-7731"
    s, r = call(AL, "/api/chat/send", {"to": f"bob@127.0.0.1:{RB}", "text": TXT}); ok("alice sends to bob across two different relays (bob offline)", s == 200)
    rows = sqlite3.connect(f"{T}/rb.db").execute("select blob from r_box where handle='bob'").fetchall(); ok("relay B holds exactly one queued message", len(rows) == 1)
    raw = b"".join(open(f"{T}/rb.db{x}", "rb").read() for x in ("", "-wal") if os.path.exists(f"{T}/rb.db{x}"))
    ok("relay stores ciphertext only (no plaintext anywhere in its files)", b"secret-plan-7731" not in raw and "secret-plan".encode() not in base64.b64decode(rows[0][0]))
    start("bob", "--db", f"{T}/bob.db", env={"POCT_PORT": str(BO)})
    th = wait(lambda: [t for t in call(BO, "/api/chat/threads")[1] if t["peer"] == f"alice@127.0.0.1:{RA}"], 15)
    ok("bob receives the message after coming online; identity survived restart", bool(th) and th[0]["unread"] == 1)
    ms = call(BO, f"/api/chat/messages?peer=alice@127.0.0.1:{RA}")[1]; ok("decrypted text is identical (Unicode + emoji)", ms[0]["body"] == TXT and ms[0]["dir"] == 0)
    ok("reading marks it as read", call(BO, "/api/chat/threads")[1][0]["unread"] == 0)
    # --- reply, errors
    call(BO, "/api/chat/send", {"to": f"alice@127.0.0.1:{RA}", "text": "Got it"}); ok("alice receives the reply", bool(wait(lambda: any(m["body"] == "Got it" for m in call(AL, f"/api/chat/messages?peer=bob@127.0.0.1:{RB}")[1]))))
    s, r = call(AL, "/api/chat/send", {"to": f"nobody@127.0.0.1:{RA}", "text": "hi"}); ok("unknown user -> 404 'No such user'", s == 404)
    s, r = call(AL, "/api/chat/send", {"to": "xyz@127.0.0.1:9", "text": "hi"}); ok("unreachable recipient server -> 502", s == 502)
    s, r = call(AL, "/api/chat/send", {"to": f"alice@127.0.0.1:{RA}", "text": "me"}); ok("cannot message yourself", s == 400)
    fp1 = call(AL, "/api/chat/identity")[1]["fingerprint"]; fp2 = call(AL, f"/api/chat/lookup?addr=bob@127.0.0.1:{RB}")[1]["fingerprint"]
    ok("safety numbers shown", len(fp1.split()) == 6 and len(fp2.split()) == 6 and fp1 != fp2)
    # --- attacks on the relay
    ok("unauthenticated inbox read -> 401", call(RA, "/relay/inbox")[0] == 401)
    ok("forged signature -> 401", call(RA, "/relay/inbox", headers={"X-Handle": "alice", "X-Ts": str(int(time.time())), "X-Sig": base64.b64encode(os.urandom(64)).decode()})[0] == 401)
    ok("oversized message refused", call(RA, "/relay/send/alice", raw=b'{"blob":"' + b"A" * 200000 + b'"}')[0] in (400, 413))
    ok("garbage blob accepted by relay but dropped by recipient", call(RA, "/relay/send/alice", {"blob": "AAAA"})[0] == 200)
    # --- sender key pinning (TOFU): tampered pin must block the message
    con = sqlite3.connect(f"{T}/alice.db", timeout=10); con.execute("update contacts set box_pk=? where addr=?", ("aa" * 32, f"bob@127.0.0.1:{RB}")); con.commit()
    before = len(call(AL, f"/api/chat/messages?peer=bob@127.0.0.1:{RB}")[1]); call(BO, "/api/chat/send", {"to": f"alice@127.0.0.1:{RA}", "text": "should be blocked"}); time.sleep(8)
    ok("message from a sender whose key does not match the pin is dropped", len(call(AL, f"/api/chat/messages?peer=bob@127.0.0.1:{RB}")[1]) == before)
    call(AL, "/api/chat/reset_contact", {"addr": f"bob@127.0.0.1:{RB}"}); call(BO, "/api/chat/send", {"to": f"alice@127.0.0.1:{RA}", "text": "after reset"})
    ok("after resetting the contact, messages flow again", bool(wait(lambda: any(m["body"] == "after reset" for m in call(AL, f"/api/chat/messages?peer=bob@127.0.0.1:{RB}")[1]))))
    # --- free host wipes its disk
    sqlite3.connect(f"{T}/ra.db").execute("delete from r_users").connection.commit()
    ok("relay data loss: engine re-registers itself automatically", bool(wait(lambda: sqlite3.connect(f"{T}/ra.db").execute("select count(*) from r_users where handle='alice'").fetchone()[0] == 1, 10)))
    call(BO, "/api/chat/send", {"to": f"alice@127.0.0.1:{RA}", "text": "post-wipe"}); ok("chat works again after the wipe", bool(wait(lambda: any(m["body"] == "post-wipe" for m in call(AL, f"/api/chat/messages?peer=bob@127.0.0.1:{RB}")[1]))))
    ok("identity DB file is private (0600)", oct(os.stat(f"{T}/alice.db").st_mode & 0o777) == "0o600")
    # --- browser UI
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={"width": 1280, "height": 760}); errs = []; pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(f"http://127.0.0.1:{AL}/"); pg.wait_for_selector("#tc"); pg.click("#tc"); pg.wait_for_selector(".n.th"); ok("UI: Chat tab lists conversations", "bob@" in pg.inner_text("#cl"))
        pg.click(".n.th >> nth=0"); pg.wait_for_selector(".b"); pg.wait_for_function("document.querySelector('#fp').textContent.includes('Safety number')"); ok("UI: thread shows bubbles + safety number", pg.locator(".b.me").count() >= 1 and pg.locator(".b:not(.me)").count() >= 1)
        pg.fill("#ct", "Hello from the browser"); pg.press("#ct", "Enter"); pg.wait_for_function("[...document.querySelectorAll('.b.me')].some(e=>e.textContent.includes('Hello from the browser'))"); ok("UI: sending shows my bubble", True)
        ok("bob received it end-to-end", bool(wait(lambda: any(m["body"] == "Hello from the browser" for m in call(BO, f"/api/chat/messages?peer=alice@127.0.0.1:{RA}")[1]))))
        call(BO, "/api/chat/send", {"to": f"alice@127.0.0.1:{RA}", "text": "Live reply via SSE"}); pg.wait_for_function("[...document.querySelectorAll('.b')].some(e=>e.textContent.includes('Live reply via SSE'))", timeout=12000); ok("UI: incoming message appears live (SSE)", True)
        pg.screenshot(path="/tmp/t/chat_thread.png")
        pg.click("#tm"); pg.wait_for_timeout(500); call(BO, "/api/chat/send", {"to": f"alice@127.0.0.1:{RA}", "text": "Badge test"}); pg.wait_for_selector("#cb.badge", timeout=12000); ok("UI: unread badge on Chat tab while in Mail", True)
        pg.click("#tc"); pg.click("#nc"); pg.fill("#na", f"ghost@127.0.0.1:{RA}"); pg.click("#ngo"); pg.wait_for_function("document.querySelector('#nerr').textContent.length>0"); ok("UI: new chat with unknown user shows error", "No such user" in pg.inner_text("#nerr"))
        pg.fill("#na", f"carol@127.0.0.1:{RA}"); pg.click("#ngo"); pg.wait_for_selector("#ct"); ok("UI: new chat opens an empty composer", pg.locator(".b").count() == 0)
        pg.click("#cset"); pg.wait_for_selector("#sm.open"); ok("UI: settings show address and safety number", f"alice@127.0.0.1:{RA}" in pg.inner_text("#sa") and len(pg.inner_text("#sf").split()) == 6); pg.screenshot(path="/tmp/t/chat_settings.png"); pg.click("#sx")
        pd = b.new_page(viewport={"width": 1280, "height": 760}); pd.goto(f"http://127.0.0.1:{DA}/"); pd.click("#tc"); pd.wait_for_selector("#sgo"); pd.fill("#su", f"127.0.0.1:{RA}"); pd.fill("#sn", "dave"); pd.click("#sgo")
        pd.wait_for_function("document.body.innerText.includes('Your address')"); ok("UI: first-run chat setup form works", f"dave@127.0.0.1:{RA}" in pd.inner_text("#pane")); pd.screenshot(path="/tmp/t/chat_setup.png")
        pm = b.new_page(viewport={"width": 390, "height": 780}); pm.goto(f"http://127.0.0.1:{AL}/"); pm.click("#menu"); pm.wait_for_timeout(300); pm.click("#tc"); pm.wait_for_selector(".n.th"); pm.click(".n.th >> nth=0"); pm.wait_for_selector(".b")
        ok("UI mobile: drawer -> Chat -> conversation opens and drawer closes", pm.locator("aside.open").count() == 0); pm.screenshot(path="/tmp/t/chat_mobile.png")
        ok("no JS exceptions", errs == []); b.close()
    print(f"\nALL {n} CHAT TESTS PASSED")
finally:
    for pr in procs.values(): pr.terminate()
