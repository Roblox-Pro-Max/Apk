import asyncio,base64,quopri
M={}
s="Görüş cümə günü"
M[1]=("From: =?UTF-8?B?"+base64.b64encode("Aysel Məmmədova".encode()).decode()+"?= <aysel@example.az>\r\nSubject: =?UTF-8?B?"+base64.b64encode(s.encode()).decode()+"?=\r\nDate: Thu, 01 Oct 2026 10:30:00 +0400\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n"+quopri.encodestring("Cümə günü saat 15:00-da görüşək. Sənədləri gətir.".encode()).decode().replace("\n","\r\n")+"\r\n")
M[2]=("From: GitHub <noreply@github.com>\r\nSubject: Yeni giris\r\nDate: Fri, 02 Oct 2026 08:00:00 +0000\r\nMIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=\"XX\"\r\n\r\n--XX\r\nContent-Type: text/html; charset=utf-8\r\n\r\n<html><style>p{color:red}</style><p>HTML versiya</p></html>\r\n--XX\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"+base64.encodebytes("Yeni cihazdan giriş aşkarlandı (plain hissə).".encode()).decode().replace("\n","\r\n")+"--XX--\r\n")
M[3]=("From: news@shop.com\r\nSubject: =?ISO-8859-1?Q?Caf=E9_offer?=\r\nDate: Fri, 02 Oct 2026 09:00:00 +0000\r\nContent-Type: text/html; charset=iso-8859-1\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n<div>Caf=E9 menu<br>20% off</div>\r\n")
async def imap(r,w):
    w.write(b"* OK mock ready\r\n")
    while True:
        l=await r.readline()
        if not l:break
        p=l.decode().strip().split(" ",2); tag=p[0]; cmd=p[1].upper() if len(p)>1 else ""; rest=p[2] if len(p)>2 else ""
        if cmd=="CAPABILITY": w.write(f"* CAPABILITY IMAP4rev1\r\n{tag} OK done\r\n".encode())
        elif cmd=="LOGIN":
            ok='good' in rest; w.write((f"{tag} OK logged in\r\n" if ok else f"{tag} NO [AUTHENTICATIONFAILED] Invalid credentials\r\n").encode())
        elif cmd=="SELECT": w.write(f"* 3 EXISTS\r\n* OK [UIDVALIDITY 1]\r\n{tag} OK [READ-WRITE] done\r\n".encode())
        elif cmd=="UID" and rest.upper().startswith("SEARCH"):
            n=1
            if "UID " in rest.upper(): n=int(rest.upper().split("UID ")[-1].split(":")[0])
            ids=[k for k in M if k>=n] or [max(M)]
            w.write(f"* SEARCH {' '.join(map(str,ids))}\r\n{tag} OK done\r\n".encode())
        elif cmd=="UID" and rest.upper().startswith("FETCH"):
            u=int(rest.split()[1]); b=M[u].encode("latin1" if u==3 else "utf-8") if u!=3 else M[u].encode("latin1")
            b=M[u].encode("utf-8") if u!=3 else M[u].replace("=E9","=E9").encode()
            w.write(f"* {u} FETCH (UID {u} BODY[] {{{len(b)}}}\r\n".encode()+b+f")\r\n{tag} OK done\r\n".encode())
        elif cmd=="LOGOUT": w.write(f"* BYE\r\n{tag} OK bye\r\n".encode()); break
        else: w.write(f"{tag} OK done\r\n".encode())
        await w.drain()
    w.close()
async def smtp(r,w):
    w.write(b"220 mock\r\n")
    while True:
        l=(await r.readline()).decode()
        if not l:break
        c=l.upper()
        if c.startswith("EHLO") or c.startswith("HELO"): w.write(b"250-mock\r\n250 8BITMIME\r\n")
        elif c.startswith("DATA"):
            w.write(b"354 go\r\n"); await w.drain(); d=b""
            while not d.endswith(b"\r\n.\r\n"): d+=await r.read(4096)
            open("/tmp/t/smtp_got.txt","ab").write(d+b"=====\n"); w.write(b"250 queued\r\n")
        elif c.startswith("QUIT"): w.write(b"221 bye\r\n"); await w.drain(); break
        else:
            open("/tmp/t/smtp_cmds.txt","a").write(l); w.write(b"250 ok\r\n")
        await w.drain()
    w.close()
async def main():
    a=await asyncio.start_server(imap,"127.0.0.1",1143); b=await asyncio.start_server(smtp,"127.0.0.1",1025)
    await asyncio.gather(a.serve_forever(),b.serve_forever())
asyncio.run(main())
